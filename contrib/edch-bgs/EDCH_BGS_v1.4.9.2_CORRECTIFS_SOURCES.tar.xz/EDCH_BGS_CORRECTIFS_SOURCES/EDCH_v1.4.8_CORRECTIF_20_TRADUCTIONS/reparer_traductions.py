#!/usr/bin/env python3
"""Répare uniquement 4 clés controls dans les 6 catalogues EDCH.

Par défaut, sauvegardes sur disque puis écritures atomiques. --check ne change rien.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from locale_keys import LABELS, KEYS, patch_locale


def prepare(root: Path) -> tuple[list[tuple[Path, str, list[str]]], dict[str, list[str]]]:
    changes = []
    report = {}
    for lang in LABELS:
        p = root / 'public' / 'locales' / f'{lang}.json'
        if not p.is_file():
            raise FileNotFoundError(f'Catalogue absent : {p}')
        source = p.read_text(encoding='utf-8')
        target, missing = patch_locale(source, lang)
        report[lang] = missing
        if missing:
            # En complément à patch_locale, vérifie la conservation des autres champs.
            before = json.loads(source)
            after = json.loads(target)
            for k in before:
                if k != 'controls' and before[k] != after[k]:
                    raise ValueError(f'{lang} : changement inattendu : {k}')
            for k, v in before['controls'].items():
                if after['controls'][k] != v:
                    raise ValueError(f'{lang} : valeur existante modifiée : {k}')
            changes.append((p, target, missing))
    return changes, report


def repair(root: Path, check: bool = False) -> tuple[dict[str,list[str]], Path | None]:
    root = root.expanduser().resolve()
    if not (root / 'package.json').is_file():
        raise ValueError(f'Projet EDCH non reconnu : {root}')
    changes, report = prepare(root)  # Analyse des 6 catalogues avant toute écriture.
    if check or not changes:
        return report, None
    backup = root / '.edch-bgs-backup-v1.4.8-locales' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup.mkdir(parents=True, exist_ok=False)
    # Sauvegarder toutes les cibles avant d'en écrire une seule.
    for path, _, _ in changes:
        shutil.copy2(path, backup / path.name)
    for path, target, _ in changes:
        fd, tmpname = tempfile.mkstemp(prefix=f'.{path.name}.', suffix='.tmp', dir=path.parent)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f:
                f.write(target)
                f.flush()
                os.fsync(f.fileno())
            os.chmod(tmpname, path.stat().st_mode & 0o777)
            os.replace(tmpname, path)
        finally:
            if os.path.exists(tmpname):
                os.unlink(tmpname)
    return report, backup


def main() -> int:
    parser = argparse.ArgumentParser(description='Réparation des 20 clés de traduction EDCH')
    parser.add_argument('--project', default=str(Path.home() / 'EDCH-BGS-Manjaro'))
    parser.add_argument('--check', action='store_true', help='contrôle sans écriture')
    args = parser.parse_args()
    try:
        report, backup = repair(Path(args.project), args.check)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(f'ERREUR : {exc}', file=sys.stderr)
        return 1
    for lang, missing in report.items():
        print(f'{lang}: {len(missing)} clé(s) manquante(s)' if args.check else f'{lang}: {len(missing)} clé(s) ajoutée(s)')
    if backup:
        print('Sauvegardes :', backup)
    print('Catalogue(s) validé(s) —', 'aucune modification (--check)' if args.check else 'correction terminée')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
