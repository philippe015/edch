# EDCH BGS v1.4.8 — Correctif des 20 traductions bloquantes

Le patch Notifications v1.4.8 a été appliqué mais la compilation a échoué sur quatre clés manquantes dans `fr`, `de`, `es`, `pt`, `ru` (20 entrées). Ce correctif ne change **que** les catalogues `public/locales/*.json`, et ne modifie aucune valeur existante.

## Installation

```bash
cd ~/Téléchargements
unzip -o EDCH_v1.4.8_CORRECTIF_20_TRADUCTIONS.zip
cd EDCH_v1.4.8_CORRECTIF_20_TRADUCTIONS
./installer_manjaro.sh
```

Après réussite :

```bash
WEBKIT_DISABLE_DMABUF_RENDERER=1 ~/EDCH-BGS-Manjaro/src-tauri/target/release/edch
```

Pour appliquer sans compiler : `EDCH_NO_BUILD=1 ./installer_manjaro.sh`.
Pour vérifier sans modifier : `python3 reparer_traductions.py --check`.

Le script exécute d'abord les 6 tests unitaires, refuse les catalogues JSON invalides, sauvegarde les fichiers d'origine dans `~/EDCH-BGS-Manjaro/.edch-bgs-backup-v1.4.8-locales/`, puis lance `npm test` et `npm run app:build`. Une seconde exécution ne duplique rien. La compilation native n'est pas exécutée dans l'environnement de création du ZIP.

Ce correctif est local et n'affecte ni `.binds`, ni les bases BGS, ni la Pull Request #2.
