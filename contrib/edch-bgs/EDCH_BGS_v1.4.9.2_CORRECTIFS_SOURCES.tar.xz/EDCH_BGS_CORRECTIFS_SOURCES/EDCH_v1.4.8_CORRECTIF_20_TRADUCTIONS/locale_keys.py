#!/usr/bin/env python3
"""Complète uniquement les clés de langues des commandes EDCH dans un clone PR.

Le projet source EDCH-BGS-Manjaro n'est jamais modifié par cet utilitaire.
Un fichier dont la structure est inconnue est refusé, sans modifier les autres.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

LABELS = {
    "en": ("Action labels", "Follow EDCH", "French", "English"),
    "fr": ("Langue des commandes", "Selon EDCH", "Français", "Anglais"),
    "de": ("Sprache der Befehle", "Wie EDCH", "Französisch", "Englisch"),
    "es": ("Idioma de los controles", "Según EDCH", "Francés", "Inglés"),
    "pt": ("Idioma dos comandos", "Conforme EDCH", "Francês", "Inglês"),
    "ru": ("Язык команд", "Как в EDCH", "Французский", "Английский"),
}
KEYS = ("actionLabelsLanguage", "actionLabels_auto", "actionLabels_fr", "actionLabels_en")
CONTROL_START = re.compile(r'^([ \t]*)"controls"[ \t]*:[ \t]*\{[ \t]*\r?\n', re.MULTILINE)
CONTROL_EMPTY = re.compile(r'^([ \t]*)"controls"[ \t]*:[ \t]*\{\}[ \t]*(,?)[ \t]*$', re.MULTILINE)


def patch_locale(source: str, language: str) -> tuple[str, list[str]]:
    if language not in LABELS:
        raise ValueError(f"Langue inconnue : {language}")
    data = json.loads(source)
    if not isinstance(data, dict) or not isinstance(data.get("controls"), dict):
        raise ValueError(f"{language} : section controls absente ou invalide")
    controls = data["controls"]
    for key in KEYS:
        if key in controls and not isinstance(controls[key], str):
            raise ValueError(f"{language} : valeur invalide pour {key}")
    missing = [key for key in KEYS if key not in controls]
    if not missing:
        return source, []
    matches = list(CONTROL_START.finditer(source))
    if len(matches) == 1:
        match = matches[0]
        newline = "\r\n" if "\r\n" in match.group() else "\n"
        indent = match.group(1) + "  "
        labels = dict(zip(KEYS, LABELS[language]))
        rows = []
        for idx, key in enumerate(missing):
            comma = "," if controls or idx < len(missing) - 1 else ""
            rows.append(f'{indent}"{key}": {json.dumps(labels[key], ensure_ascii=False)}{comma}')
        result = source[:match.end()] + newline.join(rows) + newline + source[match.end():]
    elif len(matches) == 0 and len(CONTROL_EMPTY.findall(source)) == 1 and not controls:
        match = CONTROL_EMPTY.search(source)
        assert match is not None
        newline = "\r\n" if "\r\n" in source else "\n"
        indent = match.group(1)
        labels = dict(zip(KEYS, LABELS[language]))
        rows = [f'{indent}  "{key}": {json.dumps(labels[key], ensure_ascii=False)}'
                + ("," if i < len(missing) - 1 else "") for i, key in enumerate(missing)]
        replacement = (f'{indent}"controls": {{{newline}' + newline.join(rows) + newline
                       + indent + "}" + match.group(2))
        result = source[:match.start()] + replacement + source[match.end():]
    else:
        raise ValueError(f"{language} : format JSON controls inconnu; refus de modification")
    after = json.loads(result)
    if not isinstance(after, dict) or not isinstance(after.get("controls"), dict):
        raise ValueError(f"{language} : résultat JSON invalide")
    for key, val in controls.items():
        if after["controls"].get(key) != val:
            raise ValueError(f"{language} : une valeur existante aurait été modifiée : {key}")
    for key in missing:
        if after["controls"].get(key) != labels[key]:
            raise ValueError(f"{language} : ajout non vérifié : {key}")
    return result, missing


def repair(root: Path) -> dict[str, list[str]]:
    # Toutes les analyses précèdent toute écriture, afin qu'un JSON corrompu
    # n'entraîne pas une modification partielle des catalogues.
    changes: dict[Path, str] = {}
    report: dict[str, list[str]] = {}
    for language in LABELS:
        path = root / "public" / "locales" / (language + ".json")
        if not path.is_file():
            raise FileNotFoundError(f"Catalogue absent : {path}")
        before = path.read_text(encoding="utf-8")
        after, added = patch_locale(before, language)
        report[language] = added
        if added:
            changes[path] = after
    for path, content in changes.items():
        path.write_text(content, encoding="utf-8")
    return report


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 tools/fix_pr_locales_v142.py CHEMIN_DU_CLONE", file=sys.stderr)
        return 2
    try:
        report = repair(Path(sys.argv[1]).expanduser().resolve())
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERREUR locales PR : {exc}", file=sys.stderr)
        return 1
    for language, added in report.items():
        print(f"{language}: {len(added)} clé(s) ajoutée(s)" if added else f"{language}: déjà complet")
    print("Catalogues de commandes : VALIDÉS (6 langues)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
