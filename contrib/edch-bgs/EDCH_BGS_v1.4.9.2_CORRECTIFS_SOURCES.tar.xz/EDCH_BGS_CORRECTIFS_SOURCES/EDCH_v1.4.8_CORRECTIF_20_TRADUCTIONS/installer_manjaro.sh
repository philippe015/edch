#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
python3 "$HERE/tests/test_reparer_traductions.py"
[[ -f "$ROOT/package.json" ]] || { echo "Projet introuvable : $ROOT" >&2; exit 1; }
if pgrep -x edch >/dev/null; then
  echo 'Fermer EDCH avant compilation, une instance est encore ouverte.' >&2
  exit 1
fi
python3 "$HERE/reparer_traductions.py" --project "$ROOT"
if [[ "${EDCH_NO_BUILD:-0}" == '1' ]]; then
  echo 'Corrections des catalogues appliquées. Compiler ultérieurement.'
  exit 0
fi
cd "$ROOT"
npm test
npm run app:build
[[ -x src-tauri/target/release/edch ]] || { echo 'Binaire EDCH non trouvé après compilation.' >&2; exit 1; }
echo 'OK : correction des langues et compilation terminées.'
echo 'Commande : WEBKIT_DISABLE_DMABUF_RENDERER=1 "$HOME/EDCH-BGS-Manjaro/src-tauri/target/release/edch"'
