from __future__ import annotations
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from locale_keys import KEYS, LABELS, patch_locale
from reparer_traductions import repair

class TestLocaleFix(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='edch-locales-v148-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'package.json').write_text('{"name":"edch"}', encoding='utf-8')
        (self.root / 'public' / 'locales').mkdir(parents=True)
        self.original={}
        for lang in LABELS:
            # Un vrai document multi-niveaux, valeurs utilisateur à conserver.
            source=json.dumps({'about': {'title': 'bonjour & monde'},'controls': {'alpha':f'perso {lang}'},'footer':{'x':[1,2,3]}}, ensure_ascii=False, indent=2)+'\n'
            p=self.root/'public'/'locales'/f'{lang}.json'
            p.write_text(source, encoding='utf-8')
            self.original[lang]=source

    def test_add_twenty_only(self):
        report,backup=repair(self.root)
        self.assertTrue(backup and backup.is_dir())
        self.assertEqual(sum(map(len,report.values())), 24)
        for lang in LABELS:
            p=self.root/'public'/'locales'/f'{lang}.json'
            new=json.loads(p.read_text())
            self.assertEqual(new['about'], {'title':'bonjour & monde'})
            self.assertEqual(new['controls']['alpha'],f'perso {lang}')
            self.assertTrue(all(k in new['controls'] for k in KEYS))
            self.assertEqual((backup/f'{lang}.json').read_text(), self.original[lang])

    def test_check_does_not_write(self):
        report,backup=repair(self.root,True)
        self.assertIsNone(backup)
        self.assertEqual(sum(map(len,report.values())),24)
        for lang in LABELS:
            self.assertEqual((self.root/'public'/'locales'/f'{lang}.json').read_text(),self.original[lang])

    def test_idempotent(self):
        repair(self.root)
        first={lang:(self.root/'public'/'locales'/f'{lang}.json').read_bytes() for lang in LABELS}
        report,backup=repair(self.root)
        self.assertTrue(all(not x for x in report.values()))
        self.assertIsNone(backup)
        self.assertEqual(first,{lang:(self.root/'public'/'locales'/f'{lang}.json').read_bytes() for lang in LABELS})

    def test_corrupt_json_refuses_all(self):
        (self.root/'public'/'locales'/'de.json').write_text('NOT_JSON')
        with self.assertRaises(ValueError): repair(self.root)
        self.assertEqual((self.root/'public'/'locales'/'fr.json').read_text(),self.original['fr'])
        self.assertFalse((self.root/'.edch-bgs-backup-v1.4.8-locales').exists())

    def test_preserve_existing_localized_choice(self):
        source = json.dumps({'controls': {'actionLabelsLanguage':'Mon langage','unrelated':'Valeur'}},indent=2)+'\n'
        after,added=patch_locale(source,'fr')
        self.assertEqual(len(added),3)
        self.assertEqual(json.loads(after)['controls']['actionLabelsLanguage'],'Mon langage')

    def test_invalid_existing_key_rejected(self):
        p=self.root/'public'/'locales'/'es.json'
        p.write_text('{"controls":{"actionLabels_auto":false}}')
        with self.assertRaises(ValueError): repair(self.root)
        self.assertEqual((self.root/'public'/'locales'/'fr.json').read_text(),self.original['fr'])

if __name__=='__main__':
    unittest.main(verbosity=2)
