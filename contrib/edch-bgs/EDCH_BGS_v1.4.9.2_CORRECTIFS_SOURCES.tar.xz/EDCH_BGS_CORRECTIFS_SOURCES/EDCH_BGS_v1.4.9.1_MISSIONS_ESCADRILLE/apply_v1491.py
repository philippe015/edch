#!/usr/bin/env python3
"""Transactional patch of EDCH v1.4.9's wing missions UI, with manual receipts."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

HERE=Path(__file__).resolve().parent
MARK='EDCH-BGS-WING-RECEIPTS-v1.4.9.1'
PATCH_FILES=[
 'src/state/store.ts',
 'src/services/wing.ts',
 'src/features/missions/live.ts',
 'src/views/missions/index.ts',
] + [f'public/locales/{lang}.json' for lang in ('en','fr','de','es','pt','ru')]
NEW_FILES=[
 'src/features/missions/wingManual.ts',
 'test/wing-manual-v1491.test.mjs',
]

def one(text, before, after, filename):
    n=text.count(before)
    if n!=1:
        raise ValueError(f'{filename}: ancre absente ou ambiguë ({n}): {before[:85]!r}')
    return text.replace(before,after,1)

def patch_store(s):
    f='src/state/store.ts'
    s=one(s,'  /** Ids of the missions shared by hand. */\n  shared: number[];\n}',
      '  /** Ids of the missions shared by hand. */\n  shared: number[];\n'
      f'  /** {MARK}: explicit acknowledgements, scoped to the wing code. */\n'
      '  manualReceived: { id: number; code: string; at: string }[];\n}',f)
    s=one(s,'  autoShare: false,\n  shared: [],\n};',
       '  autoShare: false,\n  shared: [],\n  manualReceived: [],\n};',f)
    return s

def patch_wing(s):
    f='src/services/wing.ts'
    s=one(s,'  commodity?: string;\n  count?: number;\n}',
        f'  commodity?: string;\n  count?: number;\n  /** {MARK}: acknowledged by the member in the game, NOT detected in the journal. */\n  manualConfirmed?: boolean;\n}}',f)
    s=one(s,'  holders: string[];\n  /** Ids of active members who don\'t have it. */',
       '  holders: string[];\n  /** Which holders explicitly confirmed manually (not journal proof). */\n  manualHolders: string[];\n  /** Ids of active members who don\'t have it. */',f)
    s=one(s,'row = { mission: { ...mission }, holders: [], missing: [], mine: false };',
          'row = { mission: { ...mission }, holders: [], manualHolders: [], missing: [], mine: false };',f)
    s=one(s,'      if (!row.holders.includes(m.id)) row.holders.push(m.id);',
      '      if (!row.holders.includes(m.id)) row.holders.push(m.id);\n'
      '      if (mission.manualConfirmed && !row.manualHolders.includes(m.id)) row.manualHolders.push(m.id);',f)
    return s

def patch_live(s):
    f='src/features/missions/live.ts'
    s=one(s,'import { hoursLeft, relTime } from "../../ui/format.js";',
      'import { hoursLeft, relTime } from "../../ui/format.js";\n'
      'import { manualWingCopies, wingScope } from "./wingManual.js"; // '+MARK,f)
    s=one(s,'import {\n  sameMission,\n  toWingMission,',
      'import {\n  isActive,\n  sameMission,\n  toWingMission,',f)
    original='''export function wingMe(): WingMember {
  const s = store.state.settings.wing;
  return {
    id: wingId(),
    name: s.name.trim() || store.state.cmdr.commander || "CMDR",
    at: new Date().toISOString(),
    missions: toWingMissions(activeMissions(), isShared),
  };
}
'''
    replacement='''/** Confirmation déclarative, révocable, d'une mission reçue par un autre CMDR. */
export function hasManualReceived(id: number): boolean {
  const s = store.state.settings.wing;
  return (s.manualReceived ?? []).some((r) => r.id === id && r.code === wingScope(s.code));
}

export function setManualReceived(id: number, on: boolean): boolean {
  if (isRemote() || !link || !Number.isSafeInteger(id) || id <= 0) return false;
  const s = store.state.settings.wing;
  const code = wingScope(s.code);
  if (!s.enabled || code.length < 8) return false;
  const existing = Array.isArray(s.manualReceived) ? s.manualReceived : [];
  if (on) {
    if (hasManualReceived(id)) return true;
    // Must originate from a currently active member's JOURNAL mission, not a forwarded receipt.
    const source = [...link.members.values()]
      .filter((m) => isActive(m))
      .flatMap((m) => m.missions)
      .find((m) => m.id === id && !m.manualConfirmed);
    if (!source) return false;
    if (source.expiry && Number.isFinite(Date.parse(source.expiry)) && Date.parse(source.expiry) <= Date.now())
      return false;
    if (activeMissions().some((m) => m.id === id)) return false;
    if (toWingMissions(activeMissions(), isShared).length >= 20) return false;
  }
  const kept = existing.filter((r) => !(r.id === id && r.code === code));
  if (on) kept.push({ id, code, at: new Date().toISOString() });
  store.updateSettings({ wing: { ...s, manualReceived: kept.slice(-100) } });
  missionsChanged();
  return true;
}

export function wingMe(): WingMember {
  const s = store.state.settings.wing;
  const mine = toWingMissions(activeMissions(), isShared);
  const known = link ? [...link.members.values()].filter((m) => isActive(m)).flatMap((m) => m.missions) : [];
  return {
    id: wingId(),
    name: s.name.trim() || store.state.cmdr.commander || "CMDR",
    at: new Date().toISOString(),
    missions: [...mine, ...manualWingCopies(s.manualReceived ?? [], s.code, known, mine)].slice(0, 20),
  };
}
'''
    s=one(s,original,replacement,f)
    s=one(s,'...r.holders.map((id) => h("span.badge.ok", null, `✓ ${names.get(id) ?? "?"}`)),',
      '...r.holders.map((id) =>\n'
      '  h("span.badge.ok", null, `✓ ${names.get(id) ?? "?"}`, (r.manualHolders ?? []).includes(id) ? ` (${t("missions.manualConfirmation")})` : ""),\n'
      '),',f)
    return s

def patch_view(s):
    f='src/views/missions/index.ts'
    s=one(s,
      'import { activeMissions, isShared, setShared, syncWing, wingView } from "../../features/missions/live.js";',
      'import { activeMissions, hasManualReceived, isShared, setManualReceived, setShared, syncWing, wingView } from "../../features/missions/live.js"; // '+MARK+'\n'
      'import { wingScope } from "../../features/missions/wingManual.js";',f)
    s=one(s,'callout("info", t("common.workProgress"), t("missions.notEveryFeatureFullyWorkingYet")),',
      'callout("info", t("missions.wingTrackingTitle"), t("missions.notEveryFeatureFullyWorkingYet")),',f)
    s=one(s,'          h("p.sub", null, t("missions.otherwiseShareEachMissionShareWing")),',
      '          h("p.sub", null, t("missions.otherwiseShareEachMissionShareWing")),\n'
      '          h("p.sub", null, t("missions.manualConfirmationHelp")),',f)
    s=one(s,'                  h("th", null, t("missions.accepted")),\n                ),',
      '                  h("th", null, t("missions.accepted")),\n'
      '                  h("th", null, t("missions.manualAction")),\n'
      '                ),',f)
    s=one(s,'r.holders.map((id) => h("span.badge.ok", null, `✓ ${names.get(id) ?? "?"}`)),',
      'r.holders.map((id) => h("span.badge.ok", null, `✓ ${names.get(id) ?? "?"}`, (r.manualHolders ?? []).includes(id) ? ` (${t("missions.manualConfirmation")})` : "")),',f)
    target='''                      r.missing.map((id) => h("span.badge.muted", null, `✗ ${names.get(id) ?? "?"}`)),
                    ),
                  ),
'''
    replacement='''                      r.missing.map((id) => h("span.badge.muted", null, `✗ ${names.get(id) ?? "?"}`)),
                    ),
                    h(
                      "td",
                      null,
                      !isRemote() && hasManualReceived(r.mission.id)
                        ? h("button.ghost.small", {
                            onclick: () => {
                              if (!setManualReceived(r.mission.id, false)) toast(t("missions.manualError"));
                              this.render();
                            },
                          }, t("missions.undoManualConfirmation"))
                        : !isRemote() && !r.mine && r.missing.includes(view.me.id)
                          ? h("button.ghost.small", {
                              onclick: () => {
                                if (!setManualReceived(r.mission.id, true)) toast(t("missions.manualError"));
                                this.render();
                              },
                            }, t("missions.confirmReceivedMission"))
                          : null,
                    ),
                  ),
'''
    s=one(s,target,replacement,f)
    s=one(s,'    return h("section.card.wing", null, parts);\n  }\n}',
      '    if (!isRemote() && s.enabled) {\n      const scope = wingScope(s.code);\n      const pending = (s.manualReceived ?? []).filter(\n        (receipt) => receipt.code === scope && !view?.rows.some((row) => row.mission.id === receipt.id),\n      );\n      if (pending.length) {\n        parts.push(\n          h(\n            "div.wing-manual-offline",\n            null,\n            h("p.sub", null, t("missions.savedOfflineConfirmations")),\n            pending.slice(0, 20).map((receipt) =>\n              h(\n                "div.row",\n                null,\n                h("span.sub", null, `#${receipt.id}`),\n                h(\n                  "button.ghost.small",\n                  {\n                    onclick: () => {\n                      setManualReceived(receipt.id, false);\n                      this.render();\n                    },\n                  },\n                  t("missions.undoManualConfirmation"),\n                ),\n              ),\n            ),\n          ),\n        );\n      }\n    }\n    return h("section.card.wing", null, parts);\n  }\n}',f)
    return s

TRANSLATIONS={
'en': ['Wing mission tracking',
 'The game logs missions you accept yourself and some cargo delivery events, but may not log receiving a wingmate’s shared mission. Confirm those missions manually below after accepting them in the game. Manual confirmations are declarations, not journal verification.',
 'Manual confirmation', 'I accepted in-game', 'Undo confirmation', 'Confirm in EDCH',
 'Only confirm after accepting in Elite Dangerous. The status is shared with wingmates using EDCH and can be revoked. It is not proof from the game.',
 'Unable to update: make sure the wing link is connected and a teammate is still sharing this mission.',
 'Saved confirmations without a currently visible mission (revoke them here):'],
'fr': ['Suivi des missions d’escadrille',
 'Le jeu enregistre les missions que tu prends toi-même et certains événements de livraison, mais pas toujours la réception d’une mission partagée. Après l’avoir acceptée dans le jeu, confirme-la manuellement dans le tableau ci-dessous. Cette confirmation déclarative ne remplace pas une preuve issue du journal.',
 'manuel', 'J’ai accepté dans le jeu', 'Annuler ma confirmation', 'Confirmation EDCH',
 'Confirme uniquement après avoir accepté la mission dans Elite Dangerous. L’information est transmise aux autres membres utilisant EDCH et peut être annulée. Ce n’est pas une preuve issue du journal.',
 'Impossible de confirmer : vérifie la connexion de l’escadrille et que le coéquipier partage toujours cette mission.',
 'Confirmations enregistrées dont la mission n’est plus visible (annulation possible) :'],
'de': ['Verfolgung von Flügelmissionen',
 'Das Spiel protokolliert selbst angenommene Missionen und einige Frachtlieferungen, aber nicht immer die Annahme geteilter Missionen. Nach der Annahme im Spiel kannst du sie unten manuell bestätigen. Das ist keine Bestätigung aus dem Spieljournal.',
 'manuell', 'Im Spiel angenommen', 'Bestätigung zurücknehmen', 'EDCH-Bestätigung',
 'Bestätige erst nach Annahme im Spiel. Diese Meldung wird an EDCH-Flügelmitglieder weitergegeben und kann widerrufen werden.',
 'Bestätigung nicht möglich: Flügelverbindung und geteilte Mission prüfen.',
 'Gespeicherte Bestätigungen ohne momentan sichtbare Mission (hier widerrufbar):'],
'es': ['Seguimiento de misiones de escuadrón',
 'El juego registra las misiones que aceptas y ciertos eventos de carga, pero puede omitir la recepción de misiones compartidas. Confirma abajo una misión después de aceptarla en el juego. Esta confirmación es manual y no procede del diario.',
 'manual', 'La acepté en el juego', 'Anular confirmación', 'Confirmación EDCH',
 'Confirma solo después de aceptar la misión en Elite Dangerous. Se comparte con otros usuarios de EDCH y se puede revocar.',
 'No se pudo confirmar: comprueba la conexión y que otro miembro siga compartiendo la misión.',
 'Confirmaciones guardadas sin misión visible actualmente (puedes anularlas aquí):'],
'pt': ['Acompanhamento de missões da esquadrilha',
 'O jogo registra missões aceitas por você e algumas entregas de carga, mas pode não registrar missões recebidas da esquadrilha. Confirme manualmente abaixo após aceitar no jogo. Isso não é uma verificação do diário.',
 'manual', 'Aceitei no jogo', 'Desfazer confirmação', 'Confirmação EDCH',
 'Confirme somente após aceitar no Elite Dangerous. A confirmação é compartilhada com usuários EDCH e pode ser desfeita.',
 'Não foi possível confirmar: confira a conexão e se o colega ainda compartilha a missão.',
 'Confirmações salvas sem missão atualmente visível (é possível desfazê-las aqui):'],
'ru': ['Отслеживание миссий крыла',
 'Игра записывает самостоятельно принятые миссии и некоторые грузовые события, но может не записывать получение миссии от товарища. После принятия в игре подтвердите её вручную ниже. Это не проверка по журналу.',
 'вручную', 'Принял в игре', 'Отменить подтверждение', 'Подтверждение EDCH',
 'Подтверждайте только после принятия в Elite Dangerous. Участники крыла с EDCH увидят подтверждение; его можно отменить.',
 'Не удалось подтвердить: проверьте соединение и доступность миссии товарища.',
 'Сохранённые подтверждения без видимой миссии (можно отменить здесь):'],
}
KEYS=['wingTrackingTitle','notEveryFeatureFullyWorkingYet','manualConfirmation','confirmReceivedMission','undoManualConfirmation','manualAction','manualConfirmationHelp','manualError','savedOfflineConfirmations']

def patch_locale(s,lang):
    path=f'public/locales/{lang}.json'
    j=json.loads(s)
    section=j.get('missions')
    if not isinstance(section,dict) or 'notEveryFeatureFullyWorkingYet' not in section:
        raise ValueError(f'{path}: catalogue missions incompatible')
    # Do not rewrite huge catalogues; update and insert strings near the existing key.
    regexp=re.compile(r'(?m)^(\s*)"notEveryFeatureFullyWorkingYet":\s*"(?:\\.|[^"\\])*"(?=,?\s*$)')
    matches=list(regexp.finditer(s))
    if len(matches)!=1: raise ValueError(f'{path}: clé cible introuvable ou ambiguë')
    m=matches[0]
    indent=m.group(1)
    seq=[]
    for i,key in enumerate(KEYS):
        if key!='notEveryFeatureFullyWorkingYet' and key in section:
            raise ValueError(f'{path}: collision de traduction {key}')
        seq.append(indent+json.dumps(key,ensure_ascii=False)+': '+json.dumps(TRANSLATIONS[lang][i],ensure_ascii=False))
    # Existing JSON key is followed by comma; use it to preserve surrounding field syntax.
    s=s[:m.start()]+',\n'.join(seq)+s[m.end():]
    json.loads(s)
    return s

TRANSFORM={
 'src/state/store.ts': patch_store,
 'src/services/wing.ts': patch_wing,
 'src/features/missions/live.ts': patch_live,
 'src/views/missions/index.ts': patch_view,
}
for lang in TRANSLATIONS:
    TRANSFORM[f'public/locales/{lang}.json']=lambda s,lang=lang: patch_locale(s,lang)

def sha(x:bytes):return hashlib.sha256(x).hexdigest()

def atomic(path:Path,data:bytes):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=f'.{path.name}.tmp-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as fp:
            fp.write(data);fp.flush();os.fsync(fp.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)

def apply(root:Path,dry:bool):
    if not (root/'package.json').is_file() or not (root/'src/views/missions/index.ts').is_file():
        raise ValueError('Répertoire EDCH invalide')
    old={}
    plan={}
    for rel in PATCH_FILES:
        path=root/rel
        if not path.is_file():raise ValueError(f'Fichier requis absent : {rel}')
        b=path.read_bytes();s=b.decode('utf-8')
        old[rel]=b
        if rel.startswith('public/locales/'):
            lang=Path(rel).stem
            done='"manualConfirmationHelp"' in s and '"wingTrackingTitle"' in s
            if done:
                if not all('"'+key+'"' in s for key in KEYS):raise ValueError(f'Patch traduction partiel : {rel}')
                planned=s
            else:planned=TRANSFORM[rel](s)
        else:
            if MARK in s:
                must={'src/state/store.ts':'manualReceived:',
                      'src/services/wing.ts':'manualHolders:',
                      'src/features/missions/live.ts':'setManualReceived(',
                      'src/views/missions/index.ts':'confirmReceivedMission'}[rel]
                if must not in s:raise ValueError(f'Patch incomplet : {rel}')
                planned=s
            else:planned=TRANSFORM[rel](s)
        plan[rel]=planned.encode('utf-8')
    for rel in NEW_FILES:
        src=HERE/'overlay'/rel; dest=root/rel
        if not src.is_file():raise ValueError(f'Overlay manquant : {rel}')
        expected=src.read_bytes()
        if dest.exists() and dest.read_bytes()!=expected:
            raise ValueError(f'Fichier déjà existant et différent : {rel}')
        if dest.exists():old[rel]=dest.read_bytes()
        plan[rel]=expected
    changes=[rel for rel,data in plan.items() if old.get(rel)!=data]
    print('Projet :',root)
    print('Fichiers à modifier :',len(changes),'/ ',len(plan))
    for rel in changes:print('  '+rel)
    if dry:
        print('OK : simulation uniquement; aucune écriture');return
    if not changes:print('OK : déjà installé, aucune modification');return
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup=root/'.edch-bgs-backup-v1.4.9.1'/stamp
    for rel in changes:
        if rel in old:
            dst=backup/rel;dst.parent.mkdir(parents=True,exist_ok=True)
            atomic(dst,old[rel])
    written=[]
    try:
        for rel in changes:
            atomic(root/rel,plan[rel]);written.append(rel)
    except Exception:
        for rel in reversed(written):
            if rel in old:atomic(root/rel,old[rel])
            else:(root/rel).unlink(missing_ok=True)
        raise
    print('OK : patch appliqué et sources originales sauvegardées :',backup)
    print('Aucun journal, configuration HOTAS, données BGS ni sauvegarde locale modifiés.')

if __name__=='__main__':
    p=argparse.ArgumentParser(description='EDCH BGS v1.4.9.1 Missions escadrille')
    p.add_argument('--project',default=str(Path.home()/'EDCH-BGS-Manjaro'))
    p.add_argument('--dry-run',action='store_true')
    a=p.parse_args()
    try: apply(Path(a.project).expanduser().resolve(),a.dry_run)
    except (ValueError,OSError,UnicodeError) as e:
        print('ERREUR :',e,file=sys.stderr);sys.exit(1)
