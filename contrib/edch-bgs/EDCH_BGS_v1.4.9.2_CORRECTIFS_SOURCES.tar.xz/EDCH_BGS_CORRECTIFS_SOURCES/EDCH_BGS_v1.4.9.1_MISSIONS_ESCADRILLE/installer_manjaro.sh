#!/usr/bin/env bash
# EDCH BGS v1.4.9.1 — wing-mission manual confirmations.
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
[[ -f "$ROOT/package.json" ]] || { echo "ERREUR : projet EDCH introuvable dans $ROOT" >&2; exit 1; }
if pgrep -x edch >/dev/null 2>&1; then
  echo 'ERREUR : ferme complètement EDCH avant la modification.' >&2
  pgrep -a -x edch || true
  exit 1
fi
printf '\n=== Vérifications locales du correctif ===\n'
python3 "$HERE/tests/test_patch_v1491.py"
command -v node >/dev/null || { echo 'ERREUR : node introuvable.' >&2; exit 1; }
command -v npm >/dev/null || { echo 'ERREUR : npm introuvable.' >&2; exit 1; }
if [[ "${EDCH_NO_BUILD:-0}" != 1 ]];then
  command -v cargo >/dev/null || { echo 'ERREUR : cargo (Rust) introuvable.' >&2; exit 1; }
fi
python3 "$HERE/apply_v1491.py" --project "$ROOT" "${@}"
if [[ "${EDCH_NO_BUILD:-0}" == 1 ]];then
  echo 'OK : patch appliqué sans compilation (EDCH_NO_BUILD=1).'
  exit 0
fi
cd "$ROOT"
if [[ ! -x node_modules/.bin/prettier || ! -x node_modules/.bin/tsc ]]; then
  echo 'Installation des dépendances npm existantes...'
  npm install --no-package-lock
fi
printf '\n=== Formatage des fichiers ciblés ===\n'
node_modules/.bin/prettier --write \
  src/state/store.ts src/services/wing.ts src/features/missions/wingManual.ts \
  src/features/missions/live.ts src/views/missions/index.ts \
  public/locales/{en,fr,de,es,pt,ru}.json \
  test/wing-manual-v1491.test.mjs
printf '\n=== Tests et vérification des traductions ===\n'
npm test
printf '\n=== Construction Tauri pour Manjaro ===\n'
npm run app:build
[[ -x src-tauri/target/release/edch ]] || { echo 'ERREUR : aucun binaire de release construit.' >&2; exit 1; }
printf '\nOK : correction Missions escadrille installée et compilée.\n'
printf 'Lancement : WEBKIT_DISABLE_DMABUF_RENDERER=1 "%s/src-tauri/target/release/edch"\n' "$ROOT"
