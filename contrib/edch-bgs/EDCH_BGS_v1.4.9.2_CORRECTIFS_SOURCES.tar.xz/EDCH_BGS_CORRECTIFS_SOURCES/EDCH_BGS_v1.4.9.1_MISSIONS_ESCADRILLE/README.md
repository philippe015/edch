# EDCH BGS — correctif v1.4.9.1 : missions partagées en escadrille

**Cible :** le prototype local `~/EDCH-BGS-Manjaro`, version v1.4.9 avec les correctifs précédents.

## Problème et solution réelle

Le journal d'Elite Dangerous signale normalement les missions acceptées directement par le commandant et certains événements de mission (`MissionAccepted`, `Missions`, `CargoDepot`, `MissionCompleted`, etc.). Il ne donne pas systématiquement la réception ou l'acceptation d'une mission partagée par un autre commandant. Une application ne peut pas récupérer une preuve absente du journal.

Ce correctif remplace l'avertissement générique « Toutes les fonctions ne sont pas opérationnelles à 100 % » par une explication ciblée et ajoute une **confirmation explicite** des missions d'escadrille reçues.

- Si un membre de l'escadrille utilisant EDCH partage une mission, celle-ci apparaît dans le tableau des missions d'escadrille.
- Après l'avoir **vraiment acceptée dans Elite Dangerous**, clique sur « J'ai accepté dans le jeu ».
- La confirmation est conservée localement dans les réglages EDCH, associée au code d'escadrille. Elle est publiée via le système **ntfy.sh chiffré** existant.
- Le commandant apparaît comme détenteur avec l'étiquette **(manuel)**, y compris dans le volet des notifications.
- « Annuler ma confirmation » permet de la retirer. Les confirmations enregistrées restent annulables si la mission n'est temporairement plus visible.
- Les missions déjà connues par le journal ne sont **pas dupliquées**. Les missions expirées, absentes et les simples échos des confirmations manuelles ne créent pas de nouvelles missions.

**Limites connues** : ce mécanisme est déclaratif et **ne garantit pas** que la mission a effectivement été acceptée dans le jeu ; une confirmation peut être incorrecte si l'utilisateur clique trop tôt. La disponibilité de l'information pour les autres joueurs dépend de leur connexion EDCH, du code partagé, de la disponibilité du relais ntfy.sh et, pour l'étiquette « manuel », de l'utilisation d'une version compatible. Pour éviter de fabriquer des missions à partir de rumeurs, une mission manuelle n'est publiée que lorsqu'un membre actif la partage encore depuis son EDCH.

## Installation sur Manjaro

Ferme EDCH, puis :

```bash
cd ~/Téléchargements
unzip -o EDCH_BGS_v1.4.9.1_MISSIONS_ESCADRILLE.zip
cd EDCH_BGS_v1.4.9.1_MISSIONS_ESCADRILLE
python3 apply_v1491.py --dry-run
bash -o pipefail -c './installer_manjaro.sh 2>&1 | tee "$HOME/edch-v1491-install.log"'
```

Si `~/EDCH-BGS-Manjaro` n'est pas le répertoire du projet :

```bash
EDCH_ROOT=/chemin/vers/edch ./installer_manjaro.sh
```

Le script :

1. refuse l'installation si EDCH est en cours d'exécution ;
2. vérifie la compatibilité des fichiers sans modifier le projet ;
3. enregistre les originaux dans `.edch-bgs-backup-v1.4.9.1/<timestamp>/` ;
4. modifie uniquement les sources missions/escadrille et six catalogues de traduction ;
5. lance Prettier, `npm test` et `npm run app:build` ;
6. n'annonce une installation compilée que si toutes les commandes se terminent correctement.

**Démarrage après compilation réussie** :

```bash
WEBKIT_DISABLE_DMABUF_RENDERER=1 ~/EDCH-BGS-Manjaro/src-tauri/target/release/edch
```

## En cas d'échec

Le correctif s'arrête sur les fichiers incompatibles ; le ZIP n'écrase ni les journaux Elite, ni les données SQLite, ni les réglages BGS, ni les fichiers HOTAS `.binds`.

```bash
tail -n 80 ~/edch-v1491-install.log
```

Pour faire un essai sans compiler (usage avancé) :

```bash
EDCH_NO_BUILD=1 ./installer_manjaro.sh
```

### Restauration

La sauvegarde conserve les **fichiers sources**, pas les données utilisateur. Pour revenir à l'état précédent, ferme EDCH et restaure manuellement les fichiers depuis le dernier dossier `.edch-bgs-backup-v1.4.9.1/<timestamp>/`, supprime les deux nouveaux fichiers `src/features/missions/wingManual.ts` et `test/wing-manual-v1491.test.mjs`, puis recompile. Ne supprime pas les données utilisateur ni `~/.config`.

## Tests

- `tests/test_patch_v1491.py` : simulation sans écriture, sauvegardes, réinstallation idempotente, validité des six traductions, refus de sources incompatibles.
- `test/wing-manual-v1491.test.mjs` : cinq groupes de tests Node, lancés via `npm test`, dont mission absente, mission expirée, code différent, doublon et limite de publication.
- Le compilateur TypeScript est exécuté par le projet lors de `npm test` et `npm run app:build`.

Le changement ne touche pas la Pull Request GitHub #2 ; il est local tant que l'utilisateur ne choisit pas de le publier.
