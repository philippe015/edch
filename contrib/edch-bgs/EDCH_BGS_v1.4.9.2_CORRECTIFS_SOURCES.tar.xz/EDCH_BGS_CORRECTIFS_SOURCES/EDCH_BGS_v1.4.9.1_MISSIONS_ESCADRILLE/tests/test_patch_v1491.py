#!/usr/bin/env python3
"""Regression tests for the anchored, transactional v1.4.9.1 installer."""
from pathlib import Path
import importlib.util
import json
import tempfile
import sys

BASE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('patch',BASE/'apply_v1491.py')
p=importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)

STORE='''export interface WingSettings {
  /** Ids of the missions shared by hand. */
  shared: number[];
}
export const DEFAULT_WING: WingSettings = {
  autoShare: false,
  shared: [],
};
'''
WING='''export interface WingMission {
  commodity?: string;
  count?: number;
}
export interface WingRow {
  holders: string[];
  /** Ids of active members who don't have it. */
  missing: string[];
  mine: boolean;
}
function wingRows() {
  let row = null;
      row = { mission: { ...mission }, holders: [], missing: [], mine: false };
      if (!row.holders.includes(m.id)) row.holders.push(m.id);
  return row;
}
'''
LIVE='''import { hoursLeft, relTime } from "../../ui/format.js";
import {
  sameMission,
  toWingMission,
} from "../../services/wing.js";
export function wingMe(): WingMember {
  const s = store.state.settings.wing;
  return {
    id: wingId(),
    name: s.name.trim() || store.state.cmdr.commander || "CMDR",
    at: new Date().toISOString(),
    missions: toWingMissions(activeMissions(), isShared),
  };
}
export function panel() {
  return [...r.holders.map((id) => h("span.badge.ok", null, `✓ ${names.get(id) ?? "?"}`)),];
}
'''
VIEW='''import { activeMissions, isShared, setShared, syncWing, wingView } from "../../features/missions/live.js";
callout("info", t("common.workProgress"), t("missions.notEveryFeatureFullyWorkingYet")),
          h("p.sub", null, t("missions.otherwiseShareEachMissionShareWing")),
                  h("th", null, t("missions.accepted")),
                ),
r.holders.map((id) => h("span.badge.ok", null, `✓ ${names.get(id) ?? "?"}`)),
                      r.missing.map((id) => h("span.badge.muted", null, `✗ ${names.get(id) ?? "?"}`)),
                    ),
                  ),
    return h("section.card.wing", null, parts);
  }
}
'''

def fixtures(root):
    files={
     'src/state/store.ts':STORE,
     'src/services/wing.ts':WING,
     'src/features/missions/live.ts':LIVE,
     'src/views/missions/index.ts':VIEW,
    }
    for lang in p.TRANSLATIONS:
        files[f'public/locales/{lang}.json']=json.dumps({'missions':{'notEveryFeatureFullyWorkingYet':'Old warning','other':'kept'}},ensure_ascii=False,indent=2)+'\n'
    files['package.json']='{"name":"edch-fixture"}'
    for rel,value in files.items():
        path=root/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(value,encoding='utf8')

with tempfile.TemporaryDirectory() as d:
    root=Path(d);fixtures(root)
    p.apply(root,True)
    assert not (root/'src/features/missions/wingManual.ts').exists()
    print('OK : simulation sans écriture')
    p.apply(root,False)
    assert (root/'src/features/missions/wingManual.ts').exists()
    assert (root/'test/wing-manual-v1491.test.mjs').exists()
    print('OK : nouveaux modules installés')
    a=(root/'src/views/missions/index.ts').read_text()
    assert 'J’ai accepté' not in a  # localized label stays in locale files
    assert 'confirmReceivedMission' in a and 'manualHolders' in a
    for lang in p.TRANSLATIONS:
        doc=json.loads((root/f'public/locales/{lang}.json').read_text())
        assert all(k in doc['missions'] for k in p.KEYS)
        assert doc['missions']['other']=='kept'
    print('OK : traductions complètes et textes du prototype conservés')
    original={rel:(root/rel).read_bytes() for rel in p.PATCH_FILES+p.NEW_FILES}
    p.apply(root,False)
    assert all((root/rel).read_bytes()==b for rel,b in original.items())
    print('OK : idempotence et absence de duplication')
    assert list((root/'.edch-bgs-backup-v1.4.9.1').rglob('src/state/store.ts'))
    print('OK : sauvegarde sources créée')
    wrong=root/'src/views/missions/index.ts';wrong.write_text('file changed',encoding='utf8')
    try:p.apply(root,False)
    except ValueError:pass
    else:raise AssertionError('partial patch not rejected')
    print('OK : blocage d’une installation partielle')
with tempfile.TemporaryDirectory() as d:
    root=Path(d);fixtures(root)
    (root/'src/services/wing.ts').write_text('incompatible source')
    before=(root/'src/state/store.ts').read_bytes()
    try:p.apply(root,False)
    except ValueError:pass
    else:raise AssertionError('incompatible file not refused')
    assert (root/'src/state/store.ts').read_bytes()==before
    print('OK : fichier incompatible refusé avant toute écriture')
print('6 groupes de tests du patch : OK')
