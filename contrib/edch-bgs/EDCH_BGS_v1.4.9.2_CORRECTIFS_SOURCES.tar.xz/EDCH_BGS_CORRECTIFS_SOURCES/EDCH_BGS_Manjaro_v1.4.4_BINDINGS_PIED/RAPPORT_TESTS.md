# Rapport de validation v1.4.4

- `tsc --noEmit` des nouveaux modules TypeScript sous stubs minimaux : **OK**.
- `node --test test/foot-editor-v1-4-4.test.mjs` : **9/9 OK**.
- `python3 tools/test_patch_v144.py` : **5/5 OK**.
- Tests Rust dans le module (préservation X52, protections, XML, doublons, combos) : **définis, non exécutés ici**.
- Compilation native EDCH Rust/Tauri, tests du projet complet et essais Proton : **non effectués ici**. `./installer_manjaro.sh` exécute ces validations sur Manjaro.

**Ne pas confondre les tests de l'installateur sur source représentative avec une compilation native validée.**
