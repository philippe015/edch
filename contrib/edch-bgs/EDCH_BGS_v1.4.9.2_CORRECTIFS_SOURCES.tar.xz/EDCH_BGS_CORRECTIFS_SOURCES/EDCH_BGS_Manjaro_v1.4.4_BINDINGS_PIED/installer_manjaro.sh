#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
export EDCH_ROOT="$PROJECT"
python3 "$HERE/apply_v144.py"
if [[ "${EDCH_NO_BUILD:-0}" == 1 ]]; then
  echo 'Patch appliqué, compilation désactivée (EDCH_NO_BUILD=1).'
  exit 0
fi
cd "$PROJECT"
if [[ ! -x node_modules/.bin/prettier ]]; then npm install --no-package-lock; fi
./node_modules/.bin/prettier --write \
  src/features/controls/footEdit.ts src/views/controls/footEditor.ts \
  src/views/controls/index.ts src/platform/bridge.ts test/foot-editor-v1-4-4.test.mjs
npm test
(
  cd src-tauri
  cargo test foot_binds --lib
  cargo check
)
npm run app:build
test -x src-tauri/target/release/edch || { echo 'ERREUR : binaire non produit.' >&2; exit 1; }
echo 'EDCH BGS v1.4.4 prêt. Lancer avec :'
echo 'WEBKIT_DISABLE_DMABUF_RENDERER=1 "$HOME/EDCH-BGS-Manjaro/src-tauri/target/release/edch"'
