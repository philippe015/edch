#!/usr/bin/env bash
set -euo pipefail
ROOT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
echo "EDCH : $ROOT"
files=(
  src/views/controls/index.ts
  src/views/controls/footEditor.ts
  src/features/controls/footEdit.ts
  src/platform/bridge.ts
  src-tauri/src/foot_binds.rs
  src-tauri/src/lib.rs
)
for f in "${files[@]}"; do
  if [[ ! -f "$ROOT/$f" ]]; then echo "ABSENT : $f"; exit 1; fi
  if ! grep -q 'EDCH-ONFOOT-EDIT-v1.4.4' "$ROOT/$f"; then echo "MARQUEUR ABSENT : $f"; exit 1; fi
  echo "OK : $f"
done
bin="$ROOT/src-tauri/target/release/edch"
if [[ ! -x "$bin" ]]; then
  echo 'Aucun binaire release compilé.'
  exit 1
fi
for f in "${files[@]}"; do
  if [[ "$ROOT/$f" -nt "$bin" ]]; then
    echo "Binaire obsolète : plus ancien que $f"
    exit 1
  fi
done
echo 'Sources et binaire release synchronisés (date).'
echo 'Attention : tester ensuite la création d’un profil dans Elite Dangerous.'
