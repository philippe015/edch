#!/usr/bin/env python3
"""EDCH v1.4.4: add opt-in, non-destructive on-foot keyboard preset editor.
Only applies to already installed EDCH v1.4.2/1.4.3 sources. Transactional with backups.
"""
import os, pathlib, shutil, hashlib, sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path(os.environ.get('EDCH_ROOT', os.path.expanduser('~/EDCH-BGS-Manjaro'))).resolve()
MARK = 'EDCH-ONFOOT-EDIT-v1.4.4'

def replace_one(text, old, new, path):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{path}: ancre manquante/ambiguë ({count}) : {old[:75]!r}')
    return text.replace(old, new, 1)

def patch_view(s):
    path='src/views/controls/index.ts'
    if MARK in s:
        if 'this.onFootEditor.render(' not in s:
            raise RuntimeError(f'{path}: incomplete patch')
        return s
    if 'controls.refreshBindings' not in s or 'this.note ? h("p.notice"' not in s:
        raise RuntimeError(f'{path}: expected EDCH BGS v1.4+ controls screen')
    s=replace_one(s,
        'import { keyboard } from "./keyboard.js";',
        'import { keyboard } from "./keyboard.js";\nimport { OnFootEditor } from "./footEditor.js"; // '+MARK,path)
    s=replace_one(s,
        '  private backupOut = h("div.backup-out");',
        '  private backupOut = h("div.backup-out");\n  private onFootEditor = new OnFootEditor();',path)
    anchor='      this.note ? h("p.notice", null, icon("warn"), ` ${this.note}`) : null,'
    inject='''      // EDCH-ONFOOT-EDIT-v1.4.4: edit and save a separate Odyssey keyboard-only preset.
      this.mode === "foot" ? this.onFootEditor.render(
        meta, this.binds, this.files, this.presets, this.chosen,
        () => this.render(),
        async (filename: string) => { this.chosen = filename; await this.load(); },
      ) : null,'''
    s=replace_one(s, anchor, anchor+'\n'+inject, path)
    return s

def patch_bridge(s):
    path='src/platform/bridge.ts'
    if MARK in s:
        if 'foot_save_preset' not in s: raise RuntimeError(f'{path}: incomplete patch')
        return s
    anchor='export const revealPath = (path: string) => invoke<void>("reveal_path", { path });'
    content='''// EDCH-ONFOOT-EDIT-v1.4.4: creates a NEW file, never overwrites existing presets.
export interface FootPresetResult { preset: string; filename: string; path: string; changes: number; }
export const footSavePreset = (
  sourceFile: string,
  changes: { action: string; slot: "primary" | "secondary"; key: string; modifiers: string[] }[],
): Promise<FootPresetResult> => invoke<FootPresetResult>("foot_save_preset", { sourceFile, changes });'''
    return replace_one(s,anchor,anchor+'\n'+content,path)

def patch_lib(s):
    path='src-tauri/src/lib.rs'
    if MARK in s:
        if 'foot_binds::foot_save_preset' not in s: raise RuntimeError(f'{path}: incomplete patch')
        return s
    s=replace_one(s, 'mod options;', 'mod options;\nmod foot_binds; // '+MARK,path)
    s=replace_one(s, '            options::import_config,',
                  '            options::import_config,\n            foot_binds::foot_save_preset,',path)
    return s

def main():
    if not (ROOT/'src/views/controls/index.ts').is_file():
        raise RuntimeError(f'Projet EDCH introuvable : {ROOT}')
    transforms={
        'src/views/controls/index.ts':patch_view,
        'src/platform/bridge.ts':patch_bridge,
        'src-tauri/src/lib.rs':patch_lib,
    }
    overlay={
      'src/features/controls/footEdit.ts':'overlay/src/features/controls/footEdit.ts',
      'src/views/controls/footEditor.ts':'overlay/src/views/controls/footEditor.ts',
      'src-tauri/src/foot_binds.rs':'overlay/src-tauri/src/foot_binds.rs',
      'test/foot-editor-v1-4-4.test.mjs':'overlay/test/foot-editor-v1-4-4.test.mjs',
    }
    planned={}
    for rel, transform in transforms.items():
        path=ROOT/rel
        if not path.is_file() or path.is_symlink(): raise RuntimeError(f'{rel}: invalid path')
        before=path.read_text('utf-8')
        after=transform(before)
        if before!=after: planned[rel]=after.encode()
    for rel,relative in overlay.items():
        path=ROOT/rel
        new=(HERE/relative).read_bytes()
        if path.is_symlink(): raise RuntimeError(f'{rel}: symlink refused')
        if path.exists():
            old=path.read_bytes()
            if old==new: continue
            if MARK in old.decode('utf-8',errors='replace'):
                # Prettier may have reformatted an already installed file. Protect the user's changes.
                continue
            raise RuntimeError(f'{rel}: custom file exists and is not overwritten')
        planned[rel]=new
    if not planned:
        print('EDCH v1.4.4 déjà installé ; aucune modification.')
        return
    backup=ROOT/'.edch-bgs-backup-v1.4.4'
    for rel in planned:
        src=ROOT/rel
        if src.exists():
            dst=backup/rel
            if not dst.exists():
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(src,dst)
    for rel,data in planned.items():
        dst=ROOT/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(data)
        print('v1.4.4:',rel)
    print('Éditeur À pied installé. Aucun .binds ni journal du jeu modifié pendant le patch.')

if __name__=='__main__':
    try: main()
    except Exception as ex:
        print('ERREUR :',ex,file=sys.stderr)
        sys.exit(1)
