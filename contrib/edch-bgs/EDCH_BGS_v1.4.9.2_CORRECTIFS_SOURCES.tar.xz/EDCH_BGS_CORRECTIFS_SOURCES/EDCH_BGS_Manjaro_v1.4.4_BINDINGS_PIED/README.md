# EDCH BGS Manjaro v1.4.4 — Éditeur de commandes « À pied »

Patch expérimental pour **le prototype local** EDCH-BGS-Manjaro v1.4.2 ou v1.4.3 déjà installé. Il ne touche pas au fork GitHub ni à la PR #2.

## Fonctionnement

Dans **Commandes → À pied**, un panneau **« Éditeur clavier · À pied (Odyssey) »** permet de :

1. Choisir une action à pied dans le catalogue EDCH (mouvement, sprint, rechargement, armes, etc.).
2. Choisir un emplacement **Principal** ou **Secondaire**.
3. Cliquer sur « Appuyer pour attribuer une touche », puis utiliser le clavier (lettres AZERTY, chiffres, touches F1–F12, flèches, contrôle/maj/alt ; Échap annule la capture).
4. Répéter pour plusieurs actions, retirer une modification ou effacer une touche.
5. Voir les collisions possibles entre commandes à pied partageant le même raccourci.
6. Cliquer sur **Créer le profil EDCHFoot** pour enregistrer le brouillon.

L'éditeur **ne modifie jamais le fichier .binds d'origine**. Le backend Tauri crée un nouveau profil indépendant, par exemple `EDCHFoot001.4.2.binds`, avec un `PresetName="EDCHFoot001"` cohérent. Les autres actions, notamment celles du X52 Pro, sont recopiées sans modification. Aucun `StartPreset` n'est modifié : le jeu ne change pas de profil sans action de l'utilisateur.

Après enregistrement, **redémarrer Elite Dangerous**, ouvrir **Options → Commandes → À pied**, choisir `EDCHFoot001` dans les préréglages et **Appliquer**. Les contrôles Vaisseau/SRV/Général gardent leurs profils actuels.

### Prérequis

- Elite Dangerous doit être fermé pendant l'enregistrement ; l'écriture est refusée si le jeu est détecté comme actif.
- Il faut un fichier de préréglage personnalisé `.4.x.binds` présent dans le dossier Bindings. Si EDCH signale un préréglage intégré non copié (comme `SaitekX52Pro`), modifier/enregistrer une seule touche dans le jeu pour générer `Custom.4.2.binds`, puis cliquer **Actualiser les commandes** dans EDCH.
- L'éditeur accepte les touches clavier communes ; **les caractères de ponctuation propres à certaines dispositions** ne sont pas encore pris en charge pour éviter de fabriquer un code incorrect.
- Une action déjà affectée à la **souris ou au HOTAS** dans l'emplacement choisi est protégée : utiliser l'autre emplacement s'il est libre.
- Les touches combinées (Ctrl/Alt/Maj + touche) sont acceptées, mais les doublons sont signalés plutôt que résolus automatiquement.

## Installation Manjaro

Fermer EDCH. Dans `~/Téléchargements` :

```bash
unzip -o EDCH_BGS_Manjaro_v1.4.4_BINDINGS_PIED.zip
cd EDCH_BGS_Manjaro_v1.4.4_BINDINGS_PIED
python3 tools/test_patch_v144.py
./installer_manjaro.sh
```

L'installateur applique les changements, reformate les fichiers, exécute `npm test`, `cargo test foot_binds --lib`, `cargo check`, puis `npm run app:build`. Il doit terminer **sans erreur** avant d'utiliser la nouvelle interface.

Pour vérifier les fichiers uniquement et compiler manuellement ensuite :

```bash
EDCH_NO_BUILD=1 ./installer_manjaro.sh
```

Lancer après compilation réussie :

```bash
WEBKIT_DISABLE_DMABUF_RENDERER=1 ~/EDCH-BGS-Manjaro/src-tauri/target/release/edch
```

Pour vérifier : `./diagnostic_v144.sh`.

## Sécurité des données

- `Custom.4.2.binds`, autres profils, X52 Pro et fichiers de journal : jamais modifiés par le bouton d'enregistrement.
- Pour chaque enregistrement, un nom `EDCHFoot###` inédit est réservé, jamais un nom existant.
- Le code Rust refuse les noms de fichiers contenant un chemin ou des caractères spéciaux et refuse les actions hors du contexte « À pied ».
- Les sources de l'application modifiées par l'installateur sont sauvegardées sous `.edch-bgs-backup-v1.4.4`.
- Ce patch est une **extension locale non officielle**. Test réel sous Manjaro/Proton et compilation Rust/Tauri à confirmer sur la machine de l'utilisateur.

## Vérifications réalisées avant livraison

- Compilation TypeScript stricte des deux nouveaux modules contre un environnement de test à interfaces simulées.
- 9 tests JavaScript (captures, AZERTY, collisions) : réussis.
- 5 tests du script de mise à niveau : réussis.
- 7 tests unitaires Rust définis dans `foot_binds.rs` mais **non exécutés ici**, faute d'outil Rust natif. L'installateur les exécutera sur Manjaro.

Les tests d'intégration réels avec la version installée et le jeu doivent encore être validés. Il n'est pas garanti qu'une touche particulière soit correctement interprétée par Elite Dangerous avant un essai en jeu.
