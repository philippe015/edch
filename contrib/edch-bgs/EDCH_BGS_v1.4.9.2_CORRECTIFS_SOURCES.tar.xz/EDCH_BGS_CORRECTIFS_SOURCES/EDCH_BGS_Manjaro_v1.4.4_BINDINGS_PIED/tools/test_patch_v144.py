#!/usr/bin/env python3
"""Patch regression on representative EDCH controls and Tauri sources; no user files touched."""
import os, pathlib, subprocess, tempfile, sys
PACKAGE=pathlib.Path(__file__).resolve().parents[1]
VIEW='''import { keyboard } from "./keyboard.js";
export class ControlsView {
  private backupOut = h("div.backup-out");
  private mode = "foot";
  private binds: any;
  private meta: any;
  private files: any;
  private presets: any;
  private chosen: any;
  private note: any;
  private render() {
    const meta = this.meta;
    replace(this.body,
      this.note ? h("p.notice", null, icon("warn"), ` ${this.note}`) : null,
      h("p", null,"controls.refreshBindings"),
    );
  }
  private body: any;
  private async load() {}
}'''
BRIDGE='''export const revealPath = (path: string) => invoke<void>("reveal_path", { path });'''
LIB='''mod options;
fn run() { tauri::generate_handler![
            options::import_config,
] }'''

def put(base, rel, data):
    p=base/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)

def run(base, expect_ok=True):
    p=subprocess.run([sys.executable,str(PACKAGE/'apply_v144.py')],env={**os.environ,'EDCH_ROOT':str(base)},text=True,capture_output=True)
    assert (p.returncode==0)==expect_ok,(p.returncode,p.stdout,p.stderr)
    return p

with tempfile.TemporaryDirectory(prefix='edch-onfoot-patch-') as temp:
    root=pathlib.Path(temp)
    put(root,'src/views/controls/index.ts',VIEW)
    put(root,'src/platform/bridge.ts',BRIDGE)
    put(root,'src-tauri/src/lib.rs',LIB)
    first=run(root)
    assert 'v1.4.4: src/views/controls/index.ts' in first.stdout
    for rel in ('src/views/controls/index.ts','src/platform/bridge.ts','src-tauri/src/lib.rs'):
        assert (root/rel).is_file()
        assert (root/rel).read_text().count('EDCH-ONFOOT-EDIT-v1.4.4') >= 1
    for rel in ('src/features/controls/footEdit.ts','src/views/controls/footEditor.ts','src-tauri/src/foot_binds.rs','test/foot-editor-v1-4-4.test.mjs'):
        assert (root/rel).is_file()
    print('OK 1 : patch installed on representative 1.4.x sources')
    before={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()}
    again=run(root)
    after={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()}
    assert before==after
    print('OK 2 : idempotence / no duplicate sources')
    assert (root/'.edch-bgs-backup-v1.4.4/src/views/controls/index.ts').read_text()==VIEW
    print('OK 3 : previous source backup intact')

with tempfile.TemporaryDirectory(prefix='edch-onfoot-patch-invalid-') as temp:
    root=pathlib.Path(temp)
    put(root,'src/views/controls/index.ts',VIEW.replace('controls.refreshBindings','unknown version'))
    put(root,'src/platform/bridge.ts',BRIDGE)
    put(root,'src-tauri/src/lib.rs',LIB)
    run(root,False)
    assert (root/'src/platform/bridge.ts').read_text()==BRIDGE
    assert not (root/'src/features/controls/footEdit.ts').exists()
    print('OK 4 : unknown source refused without partial writes')

with tempfile.TemporaryDirectory(prefix='edch-onfoot-patch-custom-') as temp:
    root=pathlib.Path(temp)
    put(root,'src/views/controls/index.ts',VIEW)
    put(root,'src/platform/bridge.ts',BRIDGE)
    put(root,'src-tauri/src/lib.rs',LIB)
    put(root,'src/features/controls/footEdit.ts','custom file that must not be overwritten')
    run(root,False)
    assert (root/'src/features/controls/footEdit.ts').read_text()=='custom file that must not be overwritten'
    assert (root/'src/views/controls/index.ts').read_text()==VIEW
    print('OK 5 : custom file protected; no partial writes')
print('All five patch tests passed')
