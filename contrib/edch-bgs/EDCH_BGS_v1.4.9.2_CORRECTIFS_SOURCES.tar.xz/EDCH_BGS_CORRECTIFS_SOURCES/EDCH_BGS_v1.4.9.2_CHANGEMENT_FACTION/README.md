# EDCH BGS v1.4.9.2 — Changement de faction

**Patch non officiel de sources, pour le prototype local `~/EDCH-BGS-Manjaro`.** Base : EDCH BGS v1.4.9 / v1.4.9.1. Le patch n'est pas un APK ni une application indépendante. Il ne modifie pas le dépôt GitHub ni la Pull Request #2.

## Pourquoi ce correctif ?

Dans la version précédente, la zone « Faction suivie » acceptait déjà la saisie d'une autre faction via « Actualiser Spansh », mais l'association automatique à un CMDR pouvait ensuite ramener l'ancienne faction. Il était également impossible de basculer simplement entre deux factions conservées localement sans interroger Spansh.

## Modifications effectives

- **Bouton « Changer de faction »** dans `BGS · Patrouilles → Faction suivie`, distinct de « Actualiser Spansh ».
- Saisie libre du nom exact de n'importe quelle faction (1–160 caractères), avec **suggestions des factions dont un cache BGS valide existe** dans cette installation.
- **Chargement immédiat des données locales** de la faction choisie. Si un snapshot SQLite existe, il est utilisé sans mélanger les relevés de deux factions. Si la faction est nouvelle, une liste vide est affichée jusqu'à l'actualisation Spansh.
- Enregistrement de la nouvelle faction comme **faction suivie du CMDR actuellement connecté**. Cela change uniquement une préférence EDCH, **pas la faction d'appartenance du joueur dans Elite Dangerous**. Les journaux historiques des CMDR ne sont pas effacés.
- Les données de la faction précédente sont préservées dans le cache local par faction et dans SQLite. Le changement attend d'abord la fin des écritures en attente.
- « Actualiser Spansh » utilise désormais le même mécanisme de changement sécurisé, puis recherche les systèmes du nom choisi.
- Les filtres et le graphique sélectionné sont réinitialisés après un changement, pour ne pas conserver un système de l'ancienne faction.
- Toutes les fonctions des versions précédentes restent présentes : BGS, patrouilles, rapports PDF, sauvegarde native JSON, journal CMDR, missions d'escadrille, notifications et commandes à pied.

## Installation Manjaro

Fermer toutes les fenêtres EDCH. Depuis le dossier Téléchargements :

```bash
cd ~/Téléchargements
unzip -o EDCH_BGS_v1.4.9.2_CHANGEMENT_FACTION.zip
cd EDCH_BGS_v1.4.9.2_CHANGEMENT_FACTION

# Tester le patch et vérifier sa compatibilité, sans modifier le projet
python3 tests/test_patch_v1492.py
python3 apply_v1492.py --dry-run

# Installation, formatage, npm test, cargo check, compilation native
bash -o pipefail -c './installer_manjaro.sh 2>&1 | tee "$HOME/edch-v1492-install.log"'
```

**Ne pas lancer l'ancien exécutable si la compilation échoue.** Un ancien binaire peut rester disponible sans contenir le nouveau bouton. En cas d'erreur :

```bash
tail -n 70 ~/edch-v1492-install.log
```

Après compilation réussie :

```bash
WEBKIT_DISABLE_DMABUF_RENDERER=1 ~/EDCH-BGS-Manjaro/src-tauri/target/release/edch
```

Option de reprise : `EDCH_NO_BUILD=1 ./installer_manjaro.sh` applique uniquement les sources. Recompiler ensuite par `cd ~/EDCH-BGS-Manjaro && npm test && npm run app:build`.

## Utilisation

1. Ouvrir **BGS · Patrouilles**.
2. Dans **Faction suivie**, remplacer « 1ER ASTRA MILITARUM » par le nom exact de la faction souhaitée, ou sélectionner une proposition du champ.
3. Cliquer sur **Changer de faction**. Si le CMDR est identifié, sa préférence est mise à jour dans EDCH.
4. Les systèmes déjà sauvegardés sont rechargés ; sinon cliquer sur **Actualiser Spansh**. L'application affiche uniquement les systèmes réellement obtenus de Spansh.
5. Pour revenir à l'ancienne faction, sélectionner son nom, puis cliquer de nouveau sur **Changer de faction**.

**Attention :** le fait de suivre une faction dans EDCH ne rejoint pas cette faction dans le jeu et ne garantit pas son influence. Les données Spansh restent communautaires et peuvent être anciennes ou partielles.

## Sauvegardes, restauration, sécurité

Avant de remplacer quoi que ce soit, l'installateur vérifie tous les fichiers requis. Une copie des fichiers source modifiés est conservée dans :

`~/EDCH-BGS-Manjaro/.edch-bgs-backup-v1.4.9.2/<date_UTC>/`

Cette copie contient aussi `MANIFEST.json` avec les empreintes SHA256 avant/après. Le patch ne touche à **aucun** `*.binds`, journal Elite Dangerous, base SQLite, historique localStorage, clé d'escadrille, configuration HOTAS ni donnée personnelle. Il modifie au maximum deux fichiers existants (`src/views/bgs/index.ts` et `src-tauri/tauri.conf.json`) et ajoute deux fichiers (fonction de sélection et tests). Si la configuration native a un titre personnalisé inconnu, il s'arrête avant toute modification.

Pour revenir en arrière, récupérer les copies `src/views/bgs/index.ts` et `src-tauri/tauri.conf.json` dans le dernier répertoire de sauvegarde v1.4.9.2, supprimer les deux fichiers nouveaux ajoutés par cette version (`src/features/bgs/factionChoice.ts` et `test/bgs-faction-choice-v1-4-9-2.test.mjs`), puis recompiler. Il est préférable de copier la sauvegarde avant toute restauration et de ne pas effacer d'éventuels changements faits entre-temps.

## Tests et limites

- Tests de patch isolés : **4 groupes réussis** (insertion ciblée, nom de fenêtre, sauvegardes + réinstallation, refus de source incompatible).
- Tests TypeScript strict + Node : **3 tests fonctionnels réussis** sur le module de validation/suggestions (dont la protection contre les caches invalides).
- Bash `-n`, syntaxe Python et compilation du module isolé vérifiés.
- **Non vérifié ici** : compilation complète de la fenêtre BGS sur ta copie exacte de v1.4.9.1, rendu WebKitGTK, accès à tes sauvegardes SQLite et requêtes Spansh réelles. L'installateur lance `npm test`, `cargo check` puis `npm run app:build` sur Manjaro et s'arrête si une étape échoue.
