#!/usr/bin/env python3
"""EDCH BGS v1.4.9.2 - safe local faction switch. Never touches player data."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile

HERE = Path(__file__).resolve().parent
MARK = "EDCH-BGS-FACTION-SWITCH-v1.4.9.2"
MAIN = "src/views/bgs/index.ts"
OVERLAY = {
    "src/features/bgs/factionChoice.ts": "overlay/src/features/bgs/factionChoice.ts",
    "test/bgs-faction-choice-v1-4-9-2.test.mjs": "overlay/test/bgs-faction-choice-v1-4-9-2.test.mjs",
}


def only(source: str, old: str, new: str, rel: str) -> str:
    count = source.count(old)
    if count != 1:
        raise ValueError(f"{rel}: point d'intégration ambigu/absent ({count}) : {old[:90]}")
    return source.replace(old, new, 1)


def patch_view(source: str) -> str:
    if MARK in source:
        for require in ("private async switchFaction()", "rememberedFactions(", '"Changer de faction"', "await this.switchFaction();"):
            if require not in source:
                raise ValueError(f"{MAIN}: correctif partiel détecté : {require}")
        return source
    prerequisites = ["private async retrieve()", "private loadCommanderFactionOnOpen()", "private async loadFromSqlite(faction: string)",
                     "EDCH-BGS-v1.4.2", "EDCH-BGS-PDF-v1.4.3", "EDCH-BGS-RELIABILITY-v1.4.9", "setCommanderFaction("]
    for p in prerequisites:
        if p not in source:
            raise ValueError(f"{MAIN}: composant attendu absent : {p}")
    source = only(source,
        'const KEY = "edch.bgs.custom.v1";',
        f'import {{ cleanFactionName, rememberedFactions, sameFactionName, validFactionSnapshot }} from "../../features/bgs/factionChoice.js"; // {MARK}\n\nconst KEY = "edch.bgs.custom.v1";', MAIN)
    # Prevent a stale/wrong cache value from changing the visible faction.
    source = only(source,
        'if (parsed && typeof parsed.faction === "string" && Array.isArray(parsed.systems) && Array.isArray(parsed.history))\n      return parsed as BgsState;',
        'if (validFactionSnapshot(parsed, faction)) return parsed;', MAIN)
    # Make "Actualiser Spansh" use the same safe switching path as the explicit button.
    begin = '    if (faction.toLocaleLowerCase() !== this.state.faction.toLocaleLowerCase()) {\n'
    idx = source.find(begin, source.find('private async retrieve()'))
    if idx < 0 or source.count(begin) != 1:
        raise ValueError(f"{MAIN}: changement de faction historique introuvable")
    end = source.find('    this.busy = true;', idx)
    old = source[idx:end]
    if end < 0 or not all(x in old for x in ('store(this.state)', 'loadFaction(faction)', 'await this.queue', 'await this.loadFromSqlite(faction)')):
        raise ValueError(f"{MAIN}: mécanisme Spansh modifié, remplacement refusé")
    source = source[:idx] + '''    if (!sameFactionName(faction, this.state.faction)) {
      await this.switchFaction();
      if (!sameFactionName(faction, this.state.faction)) return; // Never request the wrong faction.
    }
''' + source[end:]
    # Atomic switch: finish writes for the previous faction; read cache/SQLite, THEN set CMDR association.
    method = '''  // EDCH-BGS-FACTION-SWITCH-v1.4.9.2: change the monitored faction without deleting history.
  private async switchFaction() {
    const faction = cleanFactionName(this.factionInput);
    if (!faction) {
      this.message = "Nom de faction invalide (1 à 160 caractères).";
      this.render();
      return;
    }
    if (this.busy || this.loading || isRemote()) return;
    if (sameFactionName(faction, this.state.faction)) {
      this.factionInput = this.state.faction;
      this.message = `Faction déjà sélectionnée : ${this.state.faction}`;
      this.render();
      return;
    }
    this.busy = true;
    this.message = `Chargement local de ${faction}…`;
    this.render();
    try {
      await this.queue; // Previous faction's SQLite writes must finish first.
      if (!store(this.state) && !localSqlite()) throw new Error("Sauvegarde de l'ancienne faction indisponible");
      let next = loadFaction(faction);
      if (localSqlite()) {
        const saved = await readBgs(faction);
        if (saved.snapshot) {
          const parsed: unknown = JSON.parse(saved.snapshot);
          if (!validFactionSnapshot(parsed, faction)) throw new Error("Snapshot SQLite incohérent : autre faction");
          next = parsed;
        }
        next = withVisits(next, saved.visits);
      }
      const who = this.ctx.store.state.cmdr.commander?.trim();
      if (who && !setCommanderFaction(who, faction))
        throw new Error("Impossible d'associer la nouvelle faction au CMDR ; changement annulé");
      this.state = next;
      this.factionInput = this.state.faction;
      this.myFactionAutoKey = who ? who.toLocaleLowerCase() + "|" + faction.toLocaleLowerCase() : "";
      this.myFactionPage = 0;
      this.myFactionSearch = "";
      this.trendSystem = "";
      this.message = `Faction active : ${this.state.faction}. Données précédentes conservées séparément. Cliquez sur Actualiser Spansh pour rechercher les systèmes.`;
      this.changed();
    } catch (error) {
      this.message = `Changement refusé, faction initiale conservée : ${String((error as Error)?.message ?? error)}`;
      this.factionInput = this.state.faction;
      this.render();
    } finally {
      this.busy = false;
      this.render();
    }
  }

'''
    source = only(source, '  private async retrieve() {', method+'  private async retrieve() {', MAIN)
    # Make historical faction selection discoverable without storing a remote directory.
    source = only(source,
        '''    const fieldFaction = field("Nom de la faction", this.factionInput, (value) => {
      this.factionInput = value;
    });''',
        '''    const fieldFaction = field("Nom de la faction", this.factionInput, (value) => {
      this.factionInput = value;
    });
    fieldFaction.setAttribute("list", "edch-bgs-saved-factions");
    const factionsList = h(
      "datalist",
      { id: "edch-bgs-saved-factions" },
      ...rememberedFactions(
        localStorage,
        this.state.faction,
        this.ctx.store.state.cmdr.commander
          ? readCommanderLog(this.ctx.store.state.cmdr.commander).followedFaction
          : undefined,
      ).map((name) => h("option", { value: name })),
    );''', MAIN)
    source = only(source,
        '      fieldFaction,\n      btn(\n        this.busy ? "Recherche en cours" : "Actualiser Spansh",',
        '''      fieldFaction,
      factionsList,
      btn("Changer de faction", () => void this.switchFaction(), this.busy || this.loading || isRemote()),
      btn(
        this.busy ? "Recherche en cours" : "Actualiser Spansh",''', MAIN)
    return source


def patch_title(source: str) -> str:
    conf = json.loads(source)
    windows = conf.get('app',{}).get('windows',[])
    if not windows or not isinstance(windows[0],dict):raise ValueError('tauri.conf: fenêtres absentes')
    old = windows[0].get('title')
    target = 'EDCH BGS v1.4.9.2 — Elite Dangerous Companion Helper'
    if old == target:return source
    if not isinstance(old,str) or not re.match(r'^EDCH BGS v1\.4\.9(?:\.1)?\b', old):
        raise ValueError('Titre personnalisé non modifié; config incompatible : '+repr(old))
    windows[0]['title']=target
    return json.dumps(conf,ensure_ascii=False,indent=2)+'\n'


def check_no_link(path: Path, root: Path):
    if path.is_symlink():raise ValueError('Lien symbolique interdit : '+str(path))
    cur=path.parent
    while cur != root and cur != cur.parent:
        if cur.is_symlink():raise ValueError('Dossier lien symbolique interdit : '+str(cur))
        cur=cur.parent


def plan(root: Path) -> dict[str, bytes]:
    if not (root/'package.json').is_file():raise ValueError('Projet EDCH absent : '+str(root))
    required={
       MAIN:'EDCH-BGS-RELIABILITY-v1.4.9',
       'src/features/bgs/commander.ts':'setCommanderFaction',
       'src/features/bgs/sqlite.ts':'readBgs',
       'src/features/bgs/factionSystems.ts':'EDCH-BGS-v1.4.2',
    }
    for rel, needle in required.items():
        path=root/rel
        check_no_link(path,root)
        if not path.is_file() or needle not in path.read_text('utf8'):
            raise ValueError(f'Prérequis manquant {rel}: {needle}')
    result={}
    for rel, transform in [(MAIN,patch_view),('src-tauri/tauri.conf.json',patch_title)]:
        p=root/rel
        check_no_link(p,root)
        old=p.read_bytes()
        new=transform(old.decode('utf8')).encode('utf8')
        if new!=old: result[rel]=new
    for rel, source in OVERLAY.items():
        p=root/rel
        check_no_link(p,root)
        data=(HERE/source).read_bytes()
        if p.exists() and p.read_bytes()!=data:
            txt=p.read_text('utf8',errors='replace')
            required_symbol='rememberedFactions' if rel.endswith('.ts') else 'cleanFactionName'
            if MARK in txt and required_symbol in txt:
                continue # Prettier may reformat previously installed module; preserve it.
            raise ValueError(f'Fichier existant incompatible, pas d’écrasement : {rel}')
        if not p.exists():result[rel]=data
    return result


def install(root: Path, dry: bool) -> str:
    root=root.expanduser().resolve()
    changes=plan(root)
    if not changes:return 'OK : correctif déjà installé, aucune modification'
    if dry:return f'OK : simulation, {len(changes)} fichier(s) à créer ou modifier'
    archive=root/'.edch-bgs-backup-v1.4.9.2'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    archive.mkdir(parents=True,mode=0o700)
    original={}
    manifest={}
    for rel,data in changes.items():
        path=root/rel
        if path.exists():
            before=path.read_bytes()
            original[rel]=before
            backup=archive/rel
            backup.parent.mkdir(parents=True,exist_ok=True)
            backup.write_bytes(before)
        manifest[rel]={
            'before_sha256':hashlib.sha256(original[rel]).hexdigest() if rel in original else None,
            'after_sha256':hashlib.sha256(data).hexdigest(),
        }
    (archive/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    written=[]
    try:
        for rel,data in changes.items():
            p=root/rel
            p.parent.mkdir(parents=True,exist_ok=True)
            fd,temp=tempfile.mkstemp(prefix='.edch-update-',dir=p.parent)
            try:
                with os.fdopen(fd,'wb') as f:
                    f.write(data)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(temp,p)
                written.append(rel)
            finally:
                if os.path.exists(temp):os.unlink(temp)
    except Exception:
        for rel in reversed(written):
            p=root/rel
            if rel in original: p.write_bytes(original[rel])
            elif p.exists():p.unlink()
        raise
    return f'OK : {len(written)} fichier(s) installés. Sauvegardes : {archive}'


def cli():
    parser=argparse.ArgumentParser(description='EDCH BGS v1.4.9.2 — changement sécurisé de faction')
    parser.add_argument('--project',type=Path,default=Path.home()/'EDCH-BGS-Manjaro')
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    try:print(install(args.project,args.dry_run))
    except Exception as e:parser.exit(2,f'ERREUR : {e}\n')

if __name__=='__main__':cli()
