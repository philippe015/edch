#!/usr/bin/env bash
# EDCH BGS v1.4.9.2 — faction switch, local/CMDR association, no data deletion.
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
[[ -f "$ROOT/package.json" ]] || { echo "ERREUR : projet EDCH absent : $ROOT" >&2; exit 1; }
if pgrep -x edch >/dev/null; then
  echo 'ERREUR : fermer EDCH avant toute modification.' >&2
  pgrep -a -x edch || true
  exit 1
fi
python3 "$HERE/tests/test_patch_v1492.py"
python3 "$HERE/apply_v1492.py" --project "$ROOT" --dry-run
if [[ "${EDCH_NO_BUILD:-0}" != 1 ]]; then
  for program in npm node cargo; do command -v "$program" >/dev/null || { echo "ERREUR : $program absent" >&2; exit 1; }; done
fi
python3 "$HERE/apply_v1492.py" --project "$ROOT"
if [[ "${EDCH_NO_BUILD:-0}" == 1 ]]; then
  echo 'OK : code installé ; compilation non lancée (EDCH_NO_BUILD=1).'
  exit 0
fi
cd "$ROOT"
if [[ ! -x node_modules/.bin/tsc || ! -x node_modules/.bin/prettier ]]; then
  echo 'Dépendances JavaScript absentes : installation npm...'
  npm install --no-package-lock
fi
node_modules/.bin/prettier --write src/views/bgs/index.ts src/features/bgs/factionChoice.ts test/bgs-faction-choice-v1-4-9-2.test.mjs src-tauri/tauri.conf.json
npm test
(cd src-tauri && cargo check)
npm run app:build
[[ -x src-tauri/target/release/edch ]] || { echo 'ERREUR : le binaire EDCH n’a pas été généré' >&2; exit 1; }
if [[ -f "$HERE/../EDCH_BGS_Manjaro_v1.4.9_FIABILITE/diagnostic_v149.py" ]]; then
  python3 "$HERE/../EDCH_BGS_Manjaro_v1.4.9_FIABILITE/diagnostic_v149.py" "$ROOT" --strict
fi
printf '\nOK : compilation terminée ; relancer EDCH :\nWEBKIT_DISABLE_DMABUF_RENDERER=1 "%s/src-tauri/target/release/edch"\n' "$ROOT"
