# Rapport de tests — EDCH BGS v1.4.9.2

Résultats réalisés dans l'environnement de construction du patch (pas sur la machine de l'utilisateur) :

- `python3 tests/test_patch_v1492.py` : **4 groupes réussis** (compatibilité des ancres, idempotence, sauvegarde originale/empreintes, refus de réécriture incompatible).
- `tsc --strict --target ES2022 --lib ES2022,DOM --module NodeNext --moduleResolution NodeNext` : **réussi sur le module `factionChoice.ts` compilé avec une interface BgsState minimale**.
- `node --test test/bgs-faction-choice-v1-4-9-2.test.mjs` : **3 tests réussis** (validation des noms, séparation des snapshots, cache/choix précédents et clé invalide).
- `bash -n installer_manjaro.sh`, `python3 -m py_compile apply_v1492.py` : **réussis**.
- Réinstallation synthétique deux fois : **aucune duplication**.

Non testés ici : recompilation de l'ensemble du projet Tauri, rendu natif, récupération réelle de Spansh, données SQLite réelles. Tests sur Manjaro inclus dans l'installateur.
