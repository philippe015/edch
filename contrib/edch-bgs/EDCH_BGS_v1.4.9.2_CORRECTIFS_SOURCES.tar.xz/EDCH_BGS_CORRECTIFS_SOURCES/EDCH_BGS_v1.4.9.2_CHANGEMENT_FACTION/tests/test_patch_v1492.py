#!/usr/bin/env python3
"""Independent regression checks. Does not modify the user's EDCH project."""
import json
from pathlib import Path
import sys
import tempfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from apply_v1492 import patch_view, patch_title, plan, install, MARK


def fixture():
    return '''// EDCH-BGS-v1.4.2
// EDCH-BGS-PDF-v1.4.3
// EDCH-BGS-RELIABILITY-v1.4.9
import { setCommanderFaction } from "../../features/bgs/commander.js";
const KEY = "edch.bgs.custom.v1";
function loadFaction(faction: string) {
  try {
    const parsed = JSON.parse(localStorage.getItem(faction) ?? "null");
    if (parsed && typeof parsed.faction === "string" && Array.isArray(parsed.systems) && Array.isArray(parsed.history))
      return parsed as BgsState;
  } catch {}
  return { faction };
}
class BgsView {
  private busy = false;
  private async loadFromSqlite(faction: string) { return faction; }
  private loadCommanderFactionOnOpen() { setCommanderFaction("CMD", "Faction"); return; }
  private async retrieve() {
    const faction = this.factionInput.trim();
    if (!faction || this.busy) return;
    if (faction.toLocaleLowerCase() !== this.state.faction.toLocaleLowerCase()) {
      store(this.state); // keep previous faction's observations
      this.state = loadFaction(faction);
      this.factionInput = this.state.faction;
      // Let already queued writes to the previous faction finish before reading SQLite.
      await this.queue;
      await this.loadFromSqlite(faction);
    }
    this.busy = true;
    this.render();
  }
  private render() {
    const fieldFaction = field("Nom de la faction", this.factionInput, (value) => {
      this.factionInput = value;
    });
    const controlsBar = h(
      "div.bgs-actions",
      null,
      fieldFaction,
      btn(
        this.busy ? "Recherche en cours" : "Actualiser Spansh",
        () => void this.retrieve(),
      ),
    );
  }
}
'''


def populated(root:Path):
    (root/'package.json').write_text('{}')
    for rel,value in {
        'src/views/bgs/index.ts':fixture(),
        'src/features/bgs/commander.ts':'setCommanderFaction',
        'src/features/bgs/sqlite.ts':'readBgs',
        'src/features/bgs/factionSystems.ts':'EDCH-BGS-v1.4.2',
        'src-tauri/tauri.conf.json':json.dumps({'app':{'windows':[{'title':'EDCH BGS v1.4.9 — Elite Dangerous Companion Helper'}]}}),
    }.items():
        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value)


def test_patch_view():
    out=patch_view(fixture())
    for token in (MARK,'private async switchFaction()', 'await this.queue;', 'setCommanderFaction(who, faction)',
                  'validFactionSnapshot(parsed, faction)','rememberedFactions(', 'btn("Changer de faction"',
                  'await this.switchFaction();', 'Actualiser Spansh', 'loadFromSqlite'):
        assert token in out,token
    assert 'this.state = loadFaction(faction);' not in out
    assert patch_view(out)==out
    print('OK : vue BGS change de faction en conservant les fonctions existantes')


def test_title():
    a=json.dumps({'app':{'windows':[{'title':'EDCH BGS v1.4.9 — Elite Dangerous Companion Helper'}]}})
    b=patch_title(a)
    assert json.loads(b)['app']['windows'][0]['title'].startswith('EDCH BGS v1.4.9.2')
    assert patch_title(b)==b
    try:patch_title(json.dumps({'app':{'windows':[{'title':'Fenêtre personnalisée'}]}}))
    except ValueError:pass
    else:raise AssertionError('titre personnalisé écrasé')
    print('OK : titre mis à jour sans écraser les noms personnalisés')


def test_transaction():
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);populated(root)
        first=plan(root)
        assert len(first)==4,first.keys()
        assert 'src/views/missions/index.ts' not in first
        assert 'src/views/controls/footEditor.ts' not in first
        assert 'src/features/bgs/commander.ts' not in first
        assert 'simulation' in install(root,True)
        old=(root/'src/views/bgs/index.ts').read_bytes()
        assert old==fixture().encode()
        assert 'installés' in install(root,False)
        assert 'aucune modification' in install(root,False)
        assert not plan(root)
        backups=list((root/'.edch-bgs-backup-v1.4.9.2').glob('*/MANIFEST.json'))
        assert len(backups)==1
        man=json.loads(backups[0].read_text())
        assert man['src/views/bgs/index.ts']['before_sha256']
        orig=backups[0].parent/'src/views/bgs/index.ts'
        assert orig.read_bytes()==old
        assert not (root/'src/views/missions').exists()
    print('OK : installation, sauvegarde, réinstallation et préservation des autres fonctions')


def test_reject():
    try:patch_view(fixture().replace('      await this.queue;', '      await Promise.resolve();'))
    except ValueError:pass
    else:raise AssertionError('structure incompatible acceptée')
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);populated(root)
        (root/'src/features/bgs/sqlite.ts').write_text('module personnalisé')
        try:plan(root)
        except ValueError:pass
        else:raise AssertionError('prérequis manquant accepté')
        assert not (root/'.edch-bgs-backup-v1.4.9.2').exists()
    print('OK : incompatible refusé avant écriture')

if __name__=='__main__':
    test_patch_view()
    test_title()
    test_transaction()
    test_reject()
    print('4 groupes de tests du correctif v1.4.9.2 : OK')
