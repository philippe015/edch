# EDCH BGS v1.4.9 — Fiabilité générale (prototype local Manjaro)

**Patch de sources non officiel**, basé sur l'installation locale EDCH BGS v1.4.8 (EDCH officiel v0.10.11). Le projet existe déjà dans `~/EDCH-BGS-Manjaro` ; ce ZIP **n'est pas un APK ni un binaire précompilé** et ne contient pas le dépôt complet. Il ne modifie pas la Pull Request GitHub #2.

## Changements réellement implémentés

1. **Sauvegarde BGS JSON native** : sur le PC, le bouton « Sauvegarde JSON » enregistre un fichier directement dans `~/Documents/EDCH/sauvegardes-bgs/` via Rust/Tauri. Il ne dépend plus d'un téléchargement `blob:` WebKitGTK. Les noms sont uniques et aucun fichier existant n'est écrasé. Sous Linux, le dossier est en mode `0700` et les fichiers en `0600`.
2. **Import BGS sécurisé** : le fichier JSON importé est validé *avant* toute modification. Lorsque des données BGS existent, la sauvegarde native doit réussir *avant* de remplacer l'état. En cas d'échec, l'état en mémoire reste inchangé. En mode navigateur/téléphone, un téléchargement est proposé et une confirmation explicite est demandée : le téléchargement réel ne peut pas être garanti par le navigateur.
3. **Diagnostic BGS/PDF dans l'interface** : nouveau bouton « Diagnostic BGS / PDF » à côté de la sauvegarde JSON. Il vérifie les tableaux systèmes/historique, la sérialisation JSON, la génération d'un véritable PDF, son en-tête, son pied et ses pages. Il ne modifie pas les données et n'envoie rien sur le réseau.
4. **Diagnostic Manjaro détaillé** : `diagnostic_v149.py` contrôle les composants BGS v1.4.2, PDF v1.4.3, « À pied » v1.4.4, notifications v1.4.8, les six catalogues de langues, les dates des JavaScript compilés, la synchronisation CSS, le binaire natif et les processus `edch` actuellement lancés.
5. **Installation reproductible** : vérification des prérequis avant écriture, copies de sauvegarde des sources dans `.edch-bgs-backup-v1.4.9/`, manifestes SHA256, écritures atomiques, protection des modules personnalisés, réinstallation idempotente. `npm test`, les tests Rust BGS/PDF/À pied, `cargo check`, la construction Tauri et le diagnostic strict bloquent un résultat faussement réussi.
6. **Identification de la version** : titre de la fenêtre mis à jour en `EDCH BGS v1.4.9 — Elite Dangerous Companion Helper` lorsque le titre suit la convention EDCH BGS ; une fenêtre renommée manuellement n'est pas écrasée.

## Préservation des fonctions existantes

Cette mise à jour **ne supprime pas** les modules Spansh, patrouilles et BGS, le tableau personnel CMDR, les systèmes de la faction, les tendances, les CSV, les rapports PDF, l'éditeur clavier « À pied », les traductions françaises ni la correction du texte NOTIFICATIONS. Elle ne touche à aucun fichier du jeu `.binds`, aux journaux Elite Dangerous ni aux données SQLite/localStorage à l'installation.

**Prérequis obligatoires** dans les sources locales : BGS v1.4.2, vrai rapport PDF v1.4.3, éditeur « À pied » v1.4.4, notifications corrigées v1.4.8 et les corrections de traduction précédentes. Si un module manque, l'installateur s'arrête sans écraser le projet. Il ne réinstalle aucune ancienne version.

## Installation Manjaro

Fermer EDCH complètement, puis, après téléchargement du ZIP :

```bash
cd ~/Téléchargements
unzip -o EDCH_BGS_Manjaro_v1.4.9_FIABILITE.zip
cd EDCH_BGS_Manjaro_v1.4.9_FIABILITE

# Vérification sans toucher au projet
python3 tests/test_patch_v149.py
python3 apply_v149.py --dry-run

# Installation, tests et compilation
bash -o pipefail -c './installer_manjaro.sh 2>&1 | tee "$HOME/edch-v149-install.log"'
```

**Installation des sources uniquement**, sans compilation (pour diagnostic ou reprise) :

```bash
EDCH_NO_BUILD=1 ./installer_manjaro.sh
```

Après **compilation réussie**, lancer :

```bash
WEBKIT_DISABLE_DMABUF_RENDERER=1 ~/EDCH-BGS-Manjaro/src-tauri/target/release/edch
```

Vérifier :

```bash
python3 diagnostic_v149.py ~/EDCH-BGS-Manjaro --strict
```

Si les tests ou la compilation échouent, **l'ancien exécutable peut encore être présent** : ne le confondez pas avec la v1.4.9. Lire le détail :

```bash
tail -n 70 ~/edch-v149-install.log
```

## Usage après installation

- **BGS → Sauvegarde JSON** : affiche le chemin exact du nouveau fichier enregistré sous `Documents/EDCH/sauvegardes-bgs/`.
- **BGS → Diagnostic BGS / PDF** : affiche le nombre de systèmes, relevés, taille JSON, nombre de pages PDF et état des données.
- **BGS → Importer une sauvegarde** : le remplacement est arrêté si la sauvegarde native échoue, avec message d'erreur. Si les données sont vides, aucun backup préalable n'est nécessaire.
- **BGS → Télécharger le rapport PDF** : continue d'utiliser le générateur natif PDF v1.4.3 et `Documents/EDCH/rapports/`.
- **Commandes → À pied** : l'éditeur v1.4.4 est préservé ; le diagnostic vérifie sa présence, pas le fonctionnement effectif du préréglage dans le jeu.

## Restauration / confidentialité

Le script ne modifie que **7 fichiers source/test** au maximum (quatre modifications et trois nouveaux fichiers). Avant tout changement, les anciens fichiers concernés sont sauvegardés dans `~/EDCH-BGS-Manjaro/.edch-bgs-backup-v1.4.9/<horodatage>/`, avec `MANIFEST.json` indiquant les empreintes avant/après. Conserver ces copies si une restauration manuelle est nécessaire. Les données BGS de l'utilisateur ne sont **pas** ajoutées au ZIP ni publiées sur GitHub.

Le téléchargement d'un fichier JSON dans un navigateur ne prouve pas sa présence sur disque ; c'est pourquoi la sauvegarde native est obligatoire avant import sur le PC. Le répertoire de sauvegarde natif doit être accessible en écriture.

## Tests et limites

Le code TypeScript strict du module de fiabilité et ses **4 tests fonctionnels** ont été exécutés dans un environnement isolé incluant le générateur PDF v1.4.3. Le patch Python a été testé avec une copie synthétique des points d'intégration. Les tests Rust sont fournis dans `bgs_backup.rs` et lancés par l'installateur, mais **la compilation Rust/Tauri native complète ne peut pas être effectuée dans l'environnement de création du ZIP**. Le rendu réel et les fichiers BGS de ton Manjaro restent à valider sur ta machine. Ce ZIP ne prouve pas à lui seul le bon fonctionnement de l'ensemble de l'application.
