# Vérifications EDCH BGS v1.4.9

Date : 8 novembre 2026. Tests dans le conteneur de création du patch ; aucun test connecté au jeu Elite Dangerous.

| Contrôle | Résultat |
| --- | --- |
| Syntaxe Python (compilation) | OK |
| Syntaxe Bash (`bash -n`) | OK |
| Patch : planification, installation, deux installations consécutives | OK |
| Patch : backups SHA256, sans modification en simulation | OK |
| Patch : refus bridge incompatible ou module personnalisé | OK |
| Patch : sauvegarde avant remplacement BGS | OK (contrôle d'ordre dans la transformation) |
| Diagnostic : absence de binaire et JavaScript identifiée | OK |
| Diagnostic : six catalogues de langues complets reconnus | OK |
| TypeScript strict : module `reliability.ts` | OK (TypeScript 5.8.3) |
| Tests Node : JSON round-trip sans mutation, refus des données invalides, PDF multipage, HTML rejeté | 4/4 OK (Node 22.16.0) |
| Rust `cargo test`, `cargo check` | Non exécutables ici ; `cargo` absent |
| `npm test`, binaire release Tauri / AppImage réel sur Manjaro | À confirmer chez l'utilisateur |
| Import/export BGS réels et préréglage Odyssey « À pied » | À confirmer en conditions d'usage |

La présence d'un nouveau PDF et de sauvegardes JSON en mode Tauri doit être vérifiée sur la machine de l'utilisateur. Les mesures de validation n'impliquent pas une fusion automatique dans le dépôt officiel.
