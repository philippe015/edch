#!/usr/bin/env python3
"""Transactional EDCH BGS v1.4.9 reliability upgrade of an installed v1.4.8 prototype.

Only source code and tests are changed; no game files, SQLite, journal or localStorage.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
MARK = 'EDCH-BGS-RELIABILITY-v1.4.9'
MAIN = 'src/views/bgs/index.ts'


def one(s: str, needle: str, replacement: str, file: str) -> str:
    count=s.count(needle)
    if count!=1:
        raise ValueError(f'{file}: ancre manquante ou ambiguë ({count}): {needle[:80]}')
    return s.replace(needle,replacement,1)


def patch_bgs(s: str) -> str:
    if MARK in s:
        if 'diagnoseBgsReliability(' not in s or 'bgsSaveJson(' not in s or 'private importing = false' not in s:
            raise ValueError('BGS v1.4.9 partiellement installé; aucun écrasement automatique')
        return s
    if 'EDCH-BGS-v1.4.2' not in s or 'EDCH-BGS-PDF-v1.4.3' not in s:
        raise ValueError('La vue BGS doit inclure v1.4.2 et v1.4.3 PDF')
    # Preserve the old version's API while adding native JSON backup and diagnostics.
    s=one(s,
        'import { bgsSavePdf, isRemote, isTauri, spanshPost } from "../../platform/bridge.js";',
        'import { bgsSaveJson, bgsSavePdf, isRemote, isTauri, spanshPost } from "../../platform/bridge.js";\n'
        'import { diagnoseBgsReliability, verifyBgsSnapshot } from "../../features/bgs/reliability.js"; // '+MARK,
        MAIN)
    s=one(s, '  private busy = false;', '  private busy = false;\n  private importing = false;',MAIN)
    pat=re.compile(r'(?m)^  private importData\(file: File\) \{[\s\S]*?(?=^  private exportCsv\(\) \{)')
    matches=list(pat.finditer(s))
    if len(matches)!=1: raise ValueError(f'{MAIN}: bloc import/export BGS introuvable ou ambigu ({len(matches)})')
    original=matches[0].group()
    expected=['private exportJson()', 'parseBgsBackup(', 'this.state = input', 'private importData(file: File)', 'download(', 'this.changed()']
    if not all(item in original for item in expected) or original.count('private importData(')!=1 or original.count('private exportJson(')!=1:
        raise ValueError(f'{MAIN}: import/export BGS personnalisé; refus de remplacer la méthode')
    new='''  // EDCH-BGS-RELIABILITY-v1.4.9: never replace BGS data until a native backup succeeds.
  private async importData(file: File) {
    if (this.importing) return;
    if (file.size > MAX_IMPORT_BYTES) {
      this.message = "Fichier trop volumineux (maximum 2 Mo).";
      this.render();
      return;
    }
    this.importing = true;
    try {
      const input = parseBgsBackup(await file.text());
      const hasData = this.state.systems.length > 0 || this.state.history.length > 0;
      let confirmation = "";
      if (hasData) {
        const existing = verifyBgsSnapshot(this.state);
        if (isTauri() && !isRemote()) {
          confirmation = await bgsSaveJson(existing.json);
          if (!confirmation) throw new Error("Chemin de sauvegarde BGS non confirmé");
        } else {
          // Web browsers cannot confirm that the user actually kept the downloaded file.
          const stamp = new Date().toISOString().replace(/[:.]/g, "-");
          download(`EDCH-BGS-avant-import-${stamp}.json`, existing.json, "application/json;charset=utf-8");
          if (!window.confirm("Une sauvegarde JSON a été proposée au téléchargement. Vérifie qu'elle existe avant de remplacer les données BGS. Continuer ?")) {
            this.message = "Import annulé. Données BGS conservées.";
            return;
          }
        }
      }
      this.state = input;
      this.factionInput = input.faction;
      this.message = confirmation
        ? `Import validé ; sauvegarde précédente conservée : ${confirmation}`
        : "Import validé. Aucun historique précédent à sauvegarder ou confirmation utilisateur obtenue.";
      this.changed();
    } catch (e) {
      this.message = `Import refusé, données BGS conservées : ${String((e as Error)?.message ?? e)}`;
    } finally {
      this.importing = false;
      this.render();
    }
  }
  private async exportJson() {
    try {
      const backup = verifyBgsSnapshot(this.state);
      if (isTauri() && !isRemote()) {
        const path = await bgsSaveJson(backup.json);
        this.message = `Sauvegarde BGS JSON enregistrée : ${path}`;
      } else {
        download("EDCH-BGS-sauvegarde.json", backup.json, "application/json;charset=utf-8");
        this.message = "Téléchargement JSON demandé. Vérifie le fichier dans le navigateur.";
      }
    } catch (e) {
      this.message = `Échec sauvegarde BGS JSON : ${String((e as Error)?.message ?? e)}`;
    }
    this.render();
  }
  private diagnosticExport() {
    try {
      this.message = diagnoseBgsReliability(this.state, this.ctx.store.state.cmdr.commander).message;
    } catch (e) {
      this.message = `Diagnostic BGS/PDF : ${String((e as Error)?.message ?? e)}`;
    }
    this.render();
  }
'''
    s=pat.sub(lambda _:new,s,count=1)
    s=one(s,'btn("Sauvegarde JSON", () => this.exportJson()),',
            'btn("Sauvegarde JSON", () => { void this.exportJson(); }),\n'
            '      btn("Diagnostic BGS / PDF", () => this.diagnosticExport()),',MAIN)
    return s


def patch_bridge(s: str) -> str:
    file='src/platform/bridge.ts'
    if MARK in s:
        if 'bgs_save_json' not in s: raise ValueError(f'{file}: patch partiel')
        return s
    if 'bgs_save_pdf' not in s or 'foot_save_preset' not in s:
        raise ValueError(f'{file}: PDF v1.4.3 et éditeur v1.4.4 requis')
    anchor='export const revealPath = (path: string) => invoke<void>("reveal_path", { path });'
    addition='''\n// EDCH-BGS-RELIABILITY-v1.4.9: native backup, never a WebKit blob download on desktop.
export const bgsSaveJson = (snapshot: string): Promise<string> =>
  invoke<string>("bgs_save_json", { snapshot });'''
    return one(s,anchor,anchor+addition,file)


def patch_lib(s: str) -> str:
    file='src-tauri/src/lib.rs'
    if MARK in s:
        if 'bgs_backup::bgs_save_json' not in s:raise ValueError(f'{file}: patch partiel')
        return s
    if 'mod bgs_pdf;' not in s or 'mod foot_binds;' not in s:
        raise ValueError(f'{file}: PDF et éditeur « À pied » requis')
    s=one(s,'mod bgs_db;',f'mod bgs_db;\nmod bgs_backup; // {MARK}',file)
    s=one(s,'            bgs_db::bgs_health,',
          '            bgs_db::bgs_health,\n            bgs_backup::bgs_save_json,',file)
    return s


def patch_title(s: str) -> str:
    file='src-tauri/tauri.conf.json'
    obj=json.loads(s)
    windows=obj.get('app',{}).get('windows',[])
    if not windows or not isinstance(windows[0],dict):raise ValueError(f'{file}: app.windows[0] absent')
    old=windows[0].get('title')
    target='EDCH BGS v1.4.9 — Elite Dangerous Companion Helper'
    if old==target:return s
    if not isinstance(old,str) or not re.match(r'^EDCH BGS v1\.4(?:\.\d+)?\b',old):
        raise ValueError(f'{file}: titre personnalisé inconnu {old!r}; arrêt sans modification')
    windows[0]['title']=target
    return json.dumps(obj,ensure_ascii=False,indent=2)+'\n'

TRANSFORM={
    MAIN:patch_bgs,
    'src/platform/bridge.ts':patch_bridge,
    'src-tauri/src/lib.rs':patch_lib,
    'src-tauri/tauri.conf.json':patch_title,
}
OVERLAY={
    'src/features/bgs/reliability.ts':'overlay/src/features/bgs/reliability.ts',
    'src-tauri/src/bgs_backup.rs':'overlay/src-tauri/src/bgs_backup.rs',
    'test/bgs-reliability-v1-4-9.test.mjs':'overlay/test/bgs-reliability-v1-4-9.test.mjs',
}


def build_plan(root: Path)->dict[str,bytes]:
    if not (root/'package.json').is_file():raise ValueError(f'Projet EDCH introuvable : {root}')
    # Prevent patching an incomplete prototype. All source and mutation checks precede any write.
    required={
      'src/ui/notifier.ts':'EDCH-NOTIFICATIONS-V148',
      'src/views/controls/footEditor.ts':'EDCH-ONFOOT-EDIT-v1.4.4',
      'src/features/bgs/reportPdf.ts':'EDCH-BGS-PDF-v1.4.3',
    }
    for rel,marker in required.items():
        p=root/rel
        if not p.is_file() or p.is_symlink() or marker not in p.read_text('utf8'):
            raise ValueError(f'Prérequis absent : {rel} ({marker})')
    planned={}
    for rel,change in TRANSFORM.items():
        path=root/rel
        if path.is_symlink() or not path.is_file():raise ValueError(f'{rel} absent ou lien symbolique')
        before=path.read_bytes()
        after=change(before.decode('utf8')).encode('utf8')
        if before!=after: planned[rel]=after
    for rel,package in OVERLAY.items():
        path=root/rel
        if path.is_symlink():raise ValueError(f'{rel}: lien symbolique refusé')
        data=(HERE/package).read_bytes()
        if path.exists() and path.read_bytes()!=data:
            if MARK in path.read_text('utf8',errors='replace'):
                # Only treat already present modules as installed when their essential exports remain.
                txt=path.read_text('utf8')
                need={'src/features/bgs/reliability.ts':'diagnoseBgsReliability',
                      'src-tauri/src/bgs_backup.rs':'pub fn bgs_save_json',
                      'test/bgs-reliability-v1-4-9.test.mjs':'verifyBgsSnapshot'}[rel]
                if need in txt:continue   # likely Prettier formatting from previous install
            raise ValueError(f'{rel}: fichier personnalisé incompatible, refus d’écrasement')
        if not path.exists():planned[rel]=data
    return planned


def apply(root: Path, dry=False):
    root=root.expanduser().resolve()
    plan=build_plan(root)
    if not plan:return 'OK : v1.4.9 déjà appliquée (sans modifications)'
    if dry:return f'OK : {len(plan)} fichiers à modifier/créer, simulation sans écriture'
    backup_dir=root/'.edch-bgs-backup-v1.4.9'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup_dir.mkdir(parents=True,mode=0o700)
    original={}
    for rel in plan:
        p=root/rel
        original[rel]=p.read_bytes() if p.exists() else None
        if original[rel] is not None:
            dest=backup_dir/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(original[rel])
    manifest={rel:{'before_sha256':hashlib.sha256(original[rel]).hexdigest() if original[rel] is not None else None,
                   'after_sha256':hashlib.sha256(data).hexdigest()}
             for rel,data in plan.items()}
    (backup_dir/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
    changed=[]
    try:
        for rel,data in plan.items():
            p=root/rel
            p.parent.mkdir(parents=True,exist_ok=True)
            fd,tmp=tempfile.mkstemp(prefix='.edch-v149-',dir=str(p.parent))
            try:
                with os.fdopen(fd,'wb') as out:out.write(data)
                if p.exists():os.chmod(tmp,p.stat().st_mode & 0o777)
                os.replace(tmp,p)
            finally:
                if os.path.exists(tmp):os.unlink(tmp)
            changed.append(rel)
    except Exception:
        for rel in reversed(changed):
            p=root/rel
            if original[rel] is None:p.unlink(missing_ok=True)
            else:p.write_bytes(original[rel])
        raise
    return f'OK : v1.4.9 appliquée à {len(plan)} fichiers\nSauvegardes sources : {backup_dir}'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--project',type=Path,default=Path.home()/'EDCH-BGS-Manjaro')
    ap.add_argument('--dry-run',action='store_true')
    args=ap.parse_args()
    try:print(apply(args.project,args.dry_run));return 0
    except (ValueError, OSError, UnicodeError, KeyError, TypeError) as exc:
        print(f'ERREUR : {exc}',file=sys.stderr);return 1

if __name__=='__main__':sys.exit(main())
