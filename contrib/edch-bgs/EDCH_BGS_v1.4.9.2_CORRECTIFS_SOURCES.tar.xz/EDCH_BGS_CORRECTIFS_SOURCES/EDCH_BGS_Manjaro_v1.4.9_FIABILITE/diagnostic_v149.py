#!/usr/bin/env python3
"""EDCH v1.4.9 health report; checks code, compiled assets, source freshness and running binary.
No game data or secrets read, no writes.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re, subprocess, sys
from datetime import datetime
from pathlib import Path

MARK='EDCH-BGS-RELIABILITY-v1.4.9'
COMPONENTS={
 'BGS faction':('src/features/bgs/factionSystems.ts','EDCH-BGS-v1.4.2'),
 'PDF':('src/features/bgs/reportPdf.ts','EDCH-BGS-PDF-v1.4.3'),
 'Éditeur à pied':('src/views/controls/footEditor.ts','EDCH-ONFOOT-EDIT-v1.4.4'),
 'Notifications':('src/ui/notifier.ts','EDCH-NOTIFICATIONS-V148'),
 'Fiabilité':('src/features/bgs/reliability.ts',MARK),
 'Sauvegarde BGS Rust':('src-tauri/src/bgs_backup.rs',MARK),
}
KEYS=['actionLabelsLanguage','actionLabels_auto','actionLabels_fr','actionLabels_en']


def diagnose(root:Path,strict=False)->int:
    root=root.expanduser().resolve()
    print('=== EDCH BGS v1.4.9 — diagnostic sans modification ===')
    print('Projet :',root)
    failures=[]
    if not (root/'package.json').is_file():
        print('ERREUR : projet EDCH introuvable');return 1
    for label,(rel,marker) in COMPONENTS.items():
        p=root/rel
        found=p.is_file() and marker in p.read_text('utf8',errors='replace')
        print(f'{"OK" if found else "ABSENT/INCOMPATIBLE"} : {label} — {rel}')
        if not found:failures.append(label)
    try:
        langs=[]
        for lang in ('en','fr','de','es','pt','ru'):
            data=json.loads((root/f'public/locales/{lang}.json').read_text('utf8'))
            missing=[key for key in KEYS if not isinstance(data.get('controls',{}).get(key),str)]
            langs.extend(f'{lang}.{key}' for key in missing)
        print('Langues :', 'OK, 6 catalogues' if not langs else f'CLÉS MANQUANTES : {", ".join(langs)}')
        if langs:failures.append('traductions')
    except (OSError,ValueError,AttributeError) as e:
        print('ERREUR traductions :',e);failures.append('traductions')
    css=root/'public/styles.css';compiled_css=root/'dist/styles.css'
    if css.is_file() and compiled_css.is_file():
        identical=hashlib.sha256(css.read_bytes()).digest()==hashlib.sha256(compiled_css.read_bytes()).digest()
        print('CSS source / dist :', 'identiques' if identical else 'DIFFÉRENTS')
        if not identical:failures.append('CSS compilé')
    else:
        print('CSS compilé absent');failures.append('CSS compilé')
    for rel in ('src/features/bgs/reliability.ts','src/features/bgs/reportPdf.ts',
                'src/views/controls/footEditor.ts','src/ui/notifier.ts'):
        src=root/rel
        js=root/'dist/js'/Path(rel).relative_to('src').with_suffix('.js')
        if not js.is_file():
            print('JS ABSENT :',js.relative_to(root));failures.append(str(js.relative_to(root)))
        elif src.stat().st_mtime_ns > js.stat().st_mtime_ns:
            print('JS PLUS ANCIEN QUE SOURCE :',js.relative_to(root));failures.append(str(js.relative_to(root)))
        else:print('JS à jour (date) :',js.relative_to(root))
    exe=root/'src-tauri/target/release/edch'
    if exe.is_file() and os.access(exe,os.X_OK):
        print('Binaire :',exe)
        print('Date :',datetime.fromtimestamp(exe.stat().st_mtime).isoformat(timespec='seconds'))
        references=[root/p for p in ('src-tauri/src/bgs_backup.rs','src-tauri/src/bgs_pdf.rs',
                  'src-tauri/src/foot_binds.rs','src-tauri/tauri.conf.json')]
        ref=references+[root/'dist/js/features/bgs/reliability.js']
        outdated=any(p.is_file() and p.stat().st_mtime_ns > exe.stat().st_mtime_ns for p in ref)
        print('Binaire source / JS :', 'PLUS ANCIEN — recompilation requise' if outdated else 'à jour (dates)')
        if outdated:failures.append('binaire ancien')
    else:
        print('Binaire release : ABSENT');failures.append('binaire')
    try:
        out=subprocess.run(['pgrep','-x','edch'],capture_output=True,text=True,check=False)
        for pid in out.stdout.split():
            target=os.path.realpath(f'/proc/{pid}/exe')
            print(f'Processus EDCH : PID {pid} — {target}')
            if Path(target)!=exe:print('ATTENTION : autre exécutable EDCH en cours')
    except OSError:pass
    print('Rapports PDF : ~/Documents/EDCH/rapports ; sauvegardes JSON : ~/Documents/EDCH/sauvegardes-bgs')
    print('Données locales BGS, journaux et fichiers .binds : non inspectés, non modifiés')
    if failures:
        print('BILAN :',len(failures),'point(s) à corriger')
        return 1 if strict else 0
    print('BILAN : tous les contrôles statiques sont OK (essais en jeu à confirmer)')
    return 0

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('project',nargs='?',type=Path,default=Path.home()/'EDCH-BGS-Manjaro')
    p.add_argument('--strict',action='store_true')
    args=p.parse_args()
    sys.exit(diagnose(args.project,args.strict))
