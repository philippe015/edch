#!/usr/bin/env python3
import contextlib
import io
from pathlib import Path
import tempfile
import sys
import json
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from diagnostic_v149 import diagnose
from test_patch_v149 import fixture

with tempfile.TemporaryDirectory(prefix='edch-diagnostic-') as folder:
    root=fixture(Path(folder))
    output=io.StringIO()
    with contextlib.redirect_stdout(output):
        result=diagnose(root,strict=True)
    assert result == 1
    assert 'BILAN' in output.getvalue() and 'Binaire release : ABSENT' in output.getvalue()
    print('OK : diagnostic strict détecte absence binaire et ressources')
    for lang in ('en','fr','de','es','pt','ru'):
        file=root/f'public/locales/{lang}.json';file.parent.mkdir(parents=True,exist_ok=True)
        file.write_text(json.dumps({'controls':dict.fromkeys(['actionLabelsLanguage','actionLabels_auto','actionLabels_fr','actionLabels_en'],'x')}))
    with contextlib.redirect_stdout(io.StringIO()) as buffer:
        result=diagnose(root,strict=False)
    assert result == 0
    assert 'Langues : OK, 6 catalogues' in buffer.getvalue()
    print('OK : les six catalogues complets sont reconnus')
print('TESTS DIAGNOSTIC v1.4.9 : OK')
