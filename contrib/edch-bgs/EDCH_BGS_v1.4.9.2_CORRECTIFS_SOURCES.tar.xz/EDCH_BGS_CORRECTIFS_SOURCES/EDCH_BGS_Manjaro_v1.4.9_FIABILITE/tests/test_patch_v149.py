#!/usr/bin/env python3
"""Regression tests for the actual v1.4.9 upgrade transformations and backup safety."""
import contextlib
import io
import json
import pathlib
import sys
import tempfile

HERE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from apply_v149 import apply, build_plan, patch_bgs, patch_lib, patch_bridge, patch_title

BGS='''// EDCH-BGS-v1.4.2
import { bgsSavePdf, isRemote, isTauri, spanshPost } from "../../platform/bridge.js";
// EDCH-BGS-PDF-v1.4.3
class BgsView {
  private busy = false;
  private importData(file: File) {
    if (file.size > MAX_IMPORT_BYTES) return;
    void file.text().then(text => {
      const input = parseBgsBackup(text);
      this.state = input;
      this.changed();
    });
  }
  private exportJson() {
    download("EDCH-BGS-sauvegarde.json", JSON.stringify(this.state), "application/json");
  }
  private exportCsv() { console.log("csv"); }
  private render() {
    const buttons = [btn("Sauvegarde JSON", () => this.exportJson()), btn("Exporter CSV", () => this.exportCsv())];
  }
}
'''
BRIDGE='''const invoke=<T>(command:string,arg:unknown):Promise<T> => Promise.resolve(null as T);
export const revealPath = (path: string) => invoke<void>("reveal_path", { path });
export const bgsSavePdf=()=>invoke("bgs_save_pdf",{});
export const footSavePreset=()=>invoke("foot_save_preset",{});
'''
LIB='''mod bgs_db;
mod bgs_pdf;
mod foot_binds;
fn register(){
let _=[
            bgs_db::bgs_health,
            bgs_pdf::bgs_save_pdf,
            foot_binds::foot_save_preset,
];}
'''

def fixture(folder:pathlib.Path)->pathlib.Path:
    files={
        'package.json':'{"name":"edch"}',
        'src/ui/notifier.ts':'// EDCH-NOTIFICATIONS-V148\n',
        'src/views/controls/footEditor.ts':'// EDCH-ONFOOT-EDIT-v1.4.4\n',
        'src/features/bgs/reportPdf.ts':'// EDCH-BGS-PDF-v1.4.3\n',
        'src/views/bgs/index.ts':BGS,
        'src/platform/bridge.ts':BRIDGE,
        'src-tauri/src/lib.rs':LIB,
        'src-tauri/tauri.conf.json':json.dumps({'app':{'windows':[{'title':'EDCH BGS v1.4.8 — Elite Dangerous Companion Helper'}]}}),
    }
    for rel,txt in files.items():
        p=folder/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(txt,encoding='utf8')
    return folder

def check(cond,name):
    assert cond,name
    print('OK :',name)

def run():
    with tempfile.TemporaryDirectory(prefix='edch-v149-') as d:
        root=fixture(pathlib.Path(d))
        before=(root/'src/views/bgs/index.ts').read_bytes()
        plan=build_plan(root)
        check(len(plan)==7,'7 fichiers planifiés (4 sources existantes, 3 nouveaux)')
        msg=apply(root,dry=True)
        check('simulation sans écriture' in msg and (root/'src/views/bgs/index.ts').read_bytes()==before,'simulation sans modification')
        out=apply(root)
        check('v1.4.9 appliquée' in out and (root/'src-tauri/src/bgs_backup.rs').is_file(),'installation complète')
        s=(root/'src/views/bgs/index.ts').read_text('utf8')
        check('await bgsSaveJson(existing.json)' in s and s.index('await bgsSaveJson(existing.json)')<s.index('this.state = input;'),
              'sauvegarde attendue avant tout remplacement BGS')
        check('diagnosticExport()' in s and 'verifyBgsSnapshot' in s,'diagnostic BGS/PDF intégré')
        check('bgs_backup::bgs_save_json' in (root/'src-tauri/src/lib.rs').read_text(),
              'commande Rust native enregistrée')
        check('v1.4.9' in (root/'src-tauri/tauri.conf.json').read_text(), 'titre v1.4.9')
        check('déjà appliquée' in apply(root),'réinstallation sans duplication')
        backup=list((root/'.edch-bgs-backup-v1.4.9').glob('*/MANIFEST.json'))
        manifest=json.loads(backup[0].read_text())
        check(len(backup)==1 and len(manifest)==7 and (backup[0].parent/'src/views/bgs/index.ts').read_bytes()==before,
              'sauvegardes sources + SHA256 manifest')
        existing=(root/'src/views/bgs/index.ts').read_text()
        (root/'src/views/bgs/index.ts').write_text(existing+'\n// user-note\n')
        check('déjà appliquée' in apply(root) and '// user-note' in (root/'src/views/bgs/index.ts').read_text(),
              'notes utilisateur préservées après installation')
    with tempfile.TemporaryDirectory(prefix='edch-v149-invalid-') as d:
        root=fixture(pathlib.Path(d))
        (root/'src/platform/bridge.ts').write_text('const x=1;')
        old=(root/'src/views/bgs/index.ts').read_bytes()
        try: apply(root)
        except ValueError: pass
        else: raise AssertionError('Should reject incompatible bridge')
        check(old==(root/'src/views/bgs/index.ts').read_bytes() and not (root/'.edch-bgs-backup-v1.4.9').exists(),
              'rejet d’un projet incompatible sans écriture')
    with tempfile.TemporaryDirectory(prefix='edch-v149-custom-') as d:
        root=fixture(pathlib.Path(d))
        p=root/'src/features/bgs/reliability.ts';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('custom')
        try: apply(root)
        except ValueError: pass
        else:raise AssertionError('Should refuse existing custom module')
        check(p.read_text()=='custom' and 'bgsSaveJson' not in (root/'src/views/bgs/index.ts').read_text(),
              'fichier personnalisé jamais écrasé')
    check('save' in patch_bgs(BGS).lower() and patch_bgs(patch_bgs(BGS))==patch_bgs(BGS),
          'transformations idempotentes en mémoire')
    print('TOUS LES TESTS PATCH v1.4.9 : OK')
if __name__=='__main__':run()
