#!/usr/bin/env bash
# EDCH BGS v1.4.9 — safe, restartable local source upgrade.
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
export EDCH_ROOT="$ROOT"
[[ -f "$ROOT/package.json" ]] || { echo "ERREUR : projet EDCH absent : $ROOT" >&2; exit 1; }
if pgrep -x edch >/dev/null; then
  echo 'ERREUR : fermer EDCH avant installation.' >&2
  pgrep -a -x edch || true
  exit 1
fi
python3 "$HERE/tests/test_patch_v149.py"
python3 "$HERE/tests/test_diagnostic_v149.py"
if [[ "${EDCH_NO_BUILD:-0}" != 1 ]]; then
  for tool in node npm cargo; do
    command -v "$tool" >/dev/null || { echo "ERREUR : $tool absent, installer les outils de compilation Manjaro." >&2;exit 1; }
  done
fi
python3 "$HERE/apply_v149.py" --project "$ROOT" "${@}"
if [[ "${EDCH_NO_BUILD:-0}" == 1 ]]; then
  echo 'Sources corrigées sans compilation (EDCH_NO_BUILD=1).'
  python3 "$HERE/diagnostic_v149.py" "$ROOT"
  exit 0
fi
cd "$ROOT"
if [[ ! -x node_modules/.bin/prettier || ! -x node_modules/.bin/tsc ]];then
  echo 'Installation des dépendances npm du projet...'
  npm install --no-package-lock
fi
node_modules/.bin/prettier --write \
  src/views/bgs/index.ts src/platform/bridge.ts \
  src/features/bgs/reliability.ts test/bgs-reliability-v1-4-9.test.mjs \
  public/styles.css src/ui/notifier.ts src/views/controls/footEditor.ts \
  src-tauri/tauri.conf.json
npm test
(
  cd src-tauri
  cargo test bgs_backup --lib
  cargo test bgs_pdf --lib
  cargo test foot_binds --lib
  cargo check
)
old_stamp=0
if [[ -x src-tauri/target/release/edch ]]; then old_stamp="$(stat -c %Y src-tauri/target/release/edch)"; fi
npm run app:build
[[ -x src-tauri/target/release/edch ]] || { echo 'ERREUR : binaire EDCH non généré' >&2; exit 1; }
new_stamp="$(stat -c %Y src-tauri/target/release/edch)"
[[ "$new_stamp" -ge "$old_stamp" ]] || { echo 'ERREUR : ancien binaire détecté' >&2; exit 1; }
python3 "$HERE/diagnostic_v149.py" "$ROOT" --strict
printf '\nOK : EDCH BGS v1.4.9 compilé et contrôlé.\n'
printf 'Lancer : WEBKIT_DISABLE_DMABUF_RENDERER=1 "%s/src-tauri/target/release/edch"\n' "$ROOT"
