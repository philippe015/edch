#!/usr/bin/env bash
# PDF v1.4.3: upgrades installed v1.4.2 without applying older patches again.
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
export EDCH_ROOT="$PROJECT"
python3 "$HERE/apply_v143.py"
if [[ "${EDCH_NO_BUILD:-0}" == 1 ]]; then
  echo 'Sources v1.4.3 corrigées, compilation désactivée (EDCH_NO_BUILD=1).'
  exit 0
fi
cd "$PROJECT"
if [[ ! -x node_modules/.bin/prettier ]]; then
  echo 'Installation des dépendances npm...'
  npm install --no-package-lock
fi
./node_modules/.bin/prettier --write \
  src/features/bgs/reportPdf.ts src/views/bgs/index.ts src/platform/bridge.ts \
  test/bgs-pdf-export.test.mjs
npm test
(
  cd src-tauri
  cargo check
)
npm run app:build
if [[ ! -x src-tauri/target/release/edch ]]; then
  echo 'ERREUR : exécutable EDCH absent après compilation.' >&2
  exit 1
fi
echo 'EDCH BGS v1.4.3 compilé. Lancer avec :'
echo 'WEBKIT_DISABLE_DMABUF_RENDERER=1 "$HOME/EDCH-BGS-Manjaro/src-tauri/target/release/edch"'
