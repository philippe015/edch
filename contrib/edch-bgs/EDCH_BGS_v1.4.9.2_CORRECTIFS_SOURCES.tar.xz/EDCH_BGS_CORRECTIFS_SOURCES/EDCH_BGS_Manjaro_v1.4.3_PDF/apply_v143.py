#!/usr/bin/env python3
"""Install EDCH BGS v1.4.3 PDF fix on existing v1.4.2 sources (transactional)."""
import os, pathlib, re, shutil, sys, hashlib

PACKAGE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path(os.environ.get('EDCH_ROOT', os.path.expanduser('~/EDCH-BGS-Manjaro'))).resolve()
MARK = 'EDCH-BGS-PDF-v1.4.3'


def replace_one(source, old, new, rel):
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f'{rel}: ancre attendue une fois, trouvée {count}: {old[:76]!r}')
    return source.replace(old, new, 1)


def patch_view(source):
    rel = 'src/views/bgs/index.ts'
    if MARK in source:
        if 'buildBgsReportPdf(' not in source or 'bgsSavePdf(' not in source:
            raise RuntimeError(f'{rel}: patch incomplet, correction manuelle requise')
        return source
    if 'EDCH-BGS-v1.4.2' not in source or 'private exportReport()' not in source:
        raise RuntimeError(f'{rel}: version BGS inattendue; v1.4.2 exigée')
    source = replace_one(source,
        'import { isRemote, spanshPost } from "../../platform/bridge.js";',
        'import { bgsSavePdf, isRemote, isTauri, spanshPost } from "../../platform/bridge.js";\n'
        'import { buildBgsReportPdf } from "../../features/bgs/reportPdf.js";', rel)
    pattern = re.compile(r'  private exportReport\(\) \{\s*.*?\n  \}\n(?=  private renderTrendChart\()', re.S)
    matches = list(pattern.finditer(source))
    if len(matches) != 1:
        raise RuntimeError(f'{rel}: exportReport introuvable ou ambigu ({len(matches)})')
    new = '''  // EDCH-BGS-PDF-v1.4.3: genuine PDF, saved by Rust on desktop (no WebKit blob download).
  private async exportReport() {
    try {
      const bytes = buildBgsReportPdf(this.state, { commander: this.ctx.store.state.cmdr.commander });
      if (isTauri() && !isRemote()) {
        const path = await bgsSavePdf(bytes);
        this.message = `Rapport PDF enregistré : ${path}`;
      } else {
        // Browser / remote mode: ordinary download, without needing a Tauri backend.
        const url = URL.createObjectURL(new Blob([new Uint8Array(bytes)], { type: "application/pdf" }));
        try {
          const a = document.createElement("a");
          a.href = url;
          a.download = "EDCH-BGS-rapport.pdf";
          document.body.appendChild(a);
          a.click();
          a.remove();
          this.message = "Téléchargement PDF demandé au navigateur.";
        } finally {
          window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
        }
      }
    } catch (error) {
      this.message = `Échec export PDF : ${String((error as Error)?.message ?? error)}`;
    }
    this.render();
  }
'''
    source = pattern.sub(lambda _: new, source, count=1)
    source = replace_one(source, 'btn("Rapport imprimable / PDF", () => this.exportReport())',
                         'btn("Télécharger le rapport PDF", () => { void this.exportReport(); })', rel)
    return source


def patch_bridge(source):
    rel='src/platform/bridge.ts'
    if MARK in source:
        if 'bgs_save_pdf' not in source: raise RuntimeError(f'{rel}: marqueur sans commande')
        return source
    anchor='export const revealPath = (path: string) => invoke<void>("reveal_path", { path });'
    return replace_one(source, anchor,
                       anchor + '\n// '+MARK+'\nexport const bgsSavePdf = (bytes: Uint8Array): Promise<string> =>\n  invoke<string>("bgs_save_pdf", { data: Array.from(bytes) });',rel)


def patch_lib(source):
    rel='src-tauri/src/lib.rs'
    if MARK in source:
        if 'bgs_pdf::bgs_save_pdf' not in source: raise RuntimeError(f'{rel}: marqueur sans commande')
        return source
    source=replace_one(source,'mod bgs_db;', 'mod bgs_db;\nmod bgs_pdf; // '+MARK,rel)
    source=replace_one(source,'            bgs_db::bgs_health,',
                       '            bgs_db::bgs_health,\n            bgs_pdf::bgs_save_pdf,',rel)
    return source


def sha(b): return hashlib.sha256(b).hexdigest()


def main():
    if not (ROOT/'src/views/bgs/index.ts').is_file():
        raise RuntimeError(f'EDCH introuvable : {ROOT}')
    transforms={
        'src/views/bgs/index.ts':patch_view,
        'src/platform/bridge.ts':patch_bridge,
        'src-tauri/src/lib.rs':patch_lib,
    }
    overlay={
        'src/features/bgs/reportPdf.ts':'overlay/src/features/bgs/reportPdf.ts',
        'src-tauri/src/bgs_pdf.rs':'overlay/src-tauri/src/bgs_pdf.rs',
        'test/bgs-pdf-export.test.mjs':'overlay/test/bgs-pdf-export.test.mjs',
    }
    planned={}
    for rel,fn in transforms.items():
        f=ROOT/rel
        if not f.is_file() or f.is_symlink(): raise RuntimeError(f'{rel}: absent ou lien symbolique')
        before=f.read_text(encoding='utf-8')
        after=fn(before)
        if before!=after: planned[rel]=after.encode('utf-8')
    for rel,src in overlay.items():
        path=ROOT/rel
        new=(PACKAGE/src).read_bytes()
        if path.is_symlink(): raise RuntimeError(f'{rel}: lien symbolique refusé')
        if path.exists() and path.read_bytes()!=new:
            # Already formatted by Prettier: don't overwrite user's edits; the module is installed.
            if rel.endswith(('.ts','.mjs')) and MARK in path.read_text(encoding='utf-8',errors='replace'):
                continue
            raise RuntimeError(f'{rel}: fichier personnalisé existant non écrasé')
        if not path.exists(): planned[rel]=new
    if not planned:
        print('EDCH BGS v1.4.3 déjà installé. Aucune modification.')
        return
    backup=ROOT/'.edch-bgs-backup-v1.4.3'
    # Compute all transformations before writing. Back up originals (once) before any mutation.
    for rel in planned:
        src=ROOT/rel
        if src.exists():
            dst=backup/rel
            if not dst.exists():
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(src,dst)
    for rel,contents in planned.items():
        path=ROOT/rel
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(contents)
        print('v1.4.3:',rel)
    print('Rapport PDF natif installé; paramètres, fichiers .binds et données BGS non modifiés.')

if __name__=='__main__':
    try: main()
    except Exception as ex:
        print('ERREUR:',ex,file=sys.stderr)
        sys.exit(1)
