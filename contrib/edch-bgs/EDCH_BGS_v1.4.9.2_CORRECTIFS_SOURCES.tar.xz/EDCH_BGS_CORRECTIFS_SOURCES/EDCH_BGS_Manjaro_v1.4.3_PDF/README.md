# EDCH BGS v1.4.3 — correctif export PDF natif

Ce correctif s'applique à **EDCH BGS v1.4.2** déjà installé dans `~/EDCH-BGS-Manjaro`.
Il ne modifie ni les journaux Elite Dangerous, ni les affectations `.binds` du X52 Pro, ni la base SQLite / les données BGS.
Il est indépendant du fork GitHub et de la Pull Request officielle #2.

## Problème corrigé

Le bouton « Rapport imprimable / PDF » exportait en réalité `EDCH-BGS-rapport-imprimable.html` à ouvrir puis imprimer. Sur certaines configurations Tauri/WebKitGTK cela ne produit aucun PDF. La v1.4.3 crée un **vrai document PDF** :

- A4, multi-pages (tous les systèmes de la faction, jusqu'à 5000) ;
- synthèse, présence/contrôle, influence, tendances, alertes, sources, dates et visites ;
- nom du CMDR affiché lorsque le journal le connaît ;
- détails et notes ; les sources inconnues restent indiquées comme telles ;
- enregistrement **natif sous Linux/Windows** sans téléchargement de `blob:` WebKitGTK ;
- dans la version bureau : `~/Documents/EDCH/rapports/EDCH-BGS-rapport-<date>-<n>.pdf` sur Linux ;
- sur navigateur/téléphone : tentative de téléchargement PDF gérée par le navigateur ;
- affiche un message d'erreur explicite si l'écriture échoue.

## Installation

Fermer EDCH avant de modifier ses sources. Dans `~/Téléchargements` :

```bash
unzip -o EDCH_BGS_Manjaro_v1.4.3_CORRECTIF_PDF.zip
cd EDCH_BGS_Manjaro_v1.4.3_PDF
python3 tools/test_patch_v143.py
./installer_manjaro.sh
```

Le script n'exécute pas les anciens installateurs v1.4/v1.4.2. Il vérifie les marqueurs de la v1.4.2, effectue des copies de sécurité des trois fichiers modifiés dans `.edch-bgs-backup-v1.4.3`, met en place le générateur PDF, lance `npm test`, `cargo check`, puis `npm run app:build`.

Test à froid sans compiler :

```bash
EDCH_NO_BUILD=1 ./installer_manjaro.sh
./diagnostic_pdf.sh
```

Puis compiler par `./installer_manjaro.sh`.

Lancement après compilation complète :

```bash
WEBKIT_DISABLE_DMABUF_RENDERER=1 ~/EDCH-BGS-Manjaro/src-tauri/target/release/edch
```

Dans l'application : **BGS · Suivi & patrouilles → Télécharger le rapport PDF**. Le chemin du fichier est affiché dans la zone de message BGS.

**Attention** : le ZIP est un patch de sources, pas un AppImage ni un binaire exécutable. Nous avons testé la génération PDF et le patch, mais la compilation complète native Tauri doit être validée sur ton ordinateur.

## Limites

Les glyphes non pris en charge par Helvetica/WinAnsiEncoding (certaines écritures non latines, emoji) sont remplacés par `?`. Les noms et données de la faction ne sont pas transmis à un service externe pour générer le PDF. La provenance Spansh et l'incertitude sur les ticks restent signalées.
