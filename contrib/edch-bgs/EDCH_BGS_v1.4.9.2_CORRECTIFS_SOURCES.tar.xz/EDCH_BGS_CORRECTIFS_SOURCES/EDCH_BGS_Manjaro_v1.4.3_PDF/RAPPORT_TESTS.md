# Vérifications EDCH BGS v1.4.3 PDF

- Correction du patch Python et installation répétée : 4 tests réussis.
- PDF produit localement avec TypeScript compilé sous Node.js, sans navigateur : 4 tests réussis.
- `pdfinfo` et `pdftotext` : PDF A4 multi-pages lisible, accents français et nombre de systèmes contrôlés.
- Rendu PDF par Poppler inspecté (première et dernière page).
- Archive ZIP : test d'intégrité à faire au conditionnement.
- **Non testé ici :** `cargo check` / `npm run app:build` complets avec les sources EDCH et WebKitGTK de ton Manjaro.
