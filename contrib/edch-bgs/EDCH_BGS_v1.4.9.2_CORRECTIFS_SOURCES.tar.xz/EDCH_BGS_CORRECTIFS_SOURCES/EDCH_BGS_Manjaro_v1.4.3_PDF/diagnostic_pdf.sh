#!/usr/bin/env bash
set -eu
PROJECT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
cd "$PROJECT"
echo "Projet : $PROJECT"
ok=1
for pair in \
  'src/views/bgs/index.ts:EDCH-BGS-PDF-v1.4.3' \
  'src/platform/bridge.ts:EDCH-BGS-PDF-v1.4.3' \
  'src-tauri/src/lib.rs:EDCH-BGS-PDF-v1.4.3' \
  'src/features/bgs/reportPdf.ts:EDCH-BGS-PDF-v1.4.3' \
  'src-tauri/src/bgs_pdf.rs:EDCH-BGS-PDF-v1.4.3'
do
  file="${pair%%:*}"; mark="${pair#*:}"
  if [[ -f "$file" ]] && grep -Fq -- "$mark" "$file"; then
    echo "OK : $file"
  else
    echo "NON : $file"
    ok=0
  fi
done
if [[ $ok == 1 ]]; then echo 'Sources PDF v1.4.3 : OUI';else echo 'Sources PDF v1.4.3 : NON';fi
js='dist/js/features/bgs/reportPdf.js'
if [[ -f "$js" ]]; then
  if [[ "$js" -nt 'src/features/bgs/reportPdf.ts' ]];then echo "JavaScript PDF compilé : OUI";else echo "JavaScript PDF plus ancien que la source : NON";fi
else
  echo 'JavaScript PDF compilé : NON'
fi
bin='src-tauri/target/release/edch'
if [[ -x "$bin" ]];then
  stat -c 'Date exécutable : %y' "$bin"
  if [[ "$bin" -nt 'src-tauri/src/bgs_pdf.rs' ]];then echo 'Binaire PDF à jour : probablement';else echo 'Binaire PDF ancien : recompilation nécessaire';fi
else
  echo 'Binaire EDCH absent ou non exécutable'
fi
echo 'Dossier de sortie prévu : ~/Documents/EDCH/rapports/'
