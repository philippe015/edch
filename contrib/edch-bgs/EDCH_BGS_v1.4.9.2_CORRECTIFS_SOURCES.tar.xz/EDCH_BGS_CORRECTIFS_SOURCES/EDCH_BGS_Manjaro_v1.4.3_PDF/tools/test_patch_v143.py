#!/usr/bin/env python3
import importlib.util, os, pathlib, tempfile, unittest
P=pathlib.Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('apply_v143',P/'apply_v143.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

VIEW='''// EDCH-BGS-v1.4.2
import { isRemote, spanshPost } from "../../platform/bridge.js";
export class BgsView {
  private exportReport() {
    // Static, printable HTML.
    const html = `<html>hello</html>`;
    download("EDCH-BGS-rapport-imprimable.html", html, "text/html;charset=utf-8");
  }
  private renderTrendChart() { }
  private render() { btn("Rapport imprimable / PDF", () => this.exportReport()); }
}
'''
BRIDGE='''const invoke = () => {};
export const revealPath = (path: string) => invoke<void>("reveal_path", { path });
'''
LIB='''mod bgs_db;
fn run(){ tauri::generate_handler![
            bgs_db::bgs_health,
]}'''

class PatchTest(unittest.TestCase):
  def test_transformation_et_idempotence(self):
    v=m.patch_view(VIEW)
    self.assertIn('bgsSavePdf(bytes)',v)
    self.assertIn('buildBgsReportPdf',v)
    self.assertNotIn('rapport-imprimable.html',v)
    self.assertEqual(m.patch_view(v),v)
    b=m.patch_bridge(BRIDGE)
    self.assertIn('bgs_save_pdf',b)
    self.assertEqual(m.patch_bridge(b),b)
    l=m.patch_lib(LIB)
    self.assertIn('mod bgs_pdf;',l)
    self.assertEqual(m.patch_lib(l),l)

  def test_structure_inattendue_refusee(self):
    with self.assertRaisesRegex(RuntimeError,'version BGS inattendue'):
      m.patch_view(VIEW.replace('EDCH-BGS-v1.4.2','not-v142'))
    with self.assertRaisesRegex(RuntimeError,'ancre'):
      m.patch_view(VIEW.replace('import { isRemote, spanshPost }','import { spanshPost }'))

  def test_installation_et_sauvegardes(self):
    with tempfile.TemporaryDirectory() as tmp:
      root=pathlib.Path(tmp)
      for rel,contents in [('src/views/bgs/index.ts',VIEW),('src/platform/bridge.ts',BRIDGE),('src-tauri/src/lib.rs',LIB)]:
        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(contents)
      original=m.ROOT
      try:
        m.ROOT=root;m.main();m.main()
        self.assertEqual((root/'.edch-bgs-backup-v1.4.3/src/views/bgs/index.ts').read_text(),VIEW)
        self.assertTrue((root/'src/features/bgs/reportPdf.ts').exists())
        self.assertTrue((root/'src-tauri/src/bgs_pdf.rs').exists())
        self.assertTrue((root/'test/bgs-pdf-export.test.mjs').exists())
      finally: m.ROOT=original

  def test_une_erreur_ne_change_aucun_fichier(self):
    with tempfile.TemporaryDirectory() as tmp:
      root=pathlib.Path(tmp)
      for rel,contents in [('src/views/bgs/index.ts',VIEW),('src/platform/bridge.ts','WRONG'),('src-tauri/src/lib.rs',LIB)]:
        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(contents)
      original=m.ROOT
      try:
        m.ROOT=root
        with self.assertRaises(RuntimeError): m.main()
        self.assertEqual((root/'src/views/bgs/index.ts').read_text(),VIEW)
        self.assertFalse((root/'src/features/bgs/reportPdf.ts').exists())
      finally: m.ROOT=original

if __name__=='__main__':unittest.main(verbosity=2)
