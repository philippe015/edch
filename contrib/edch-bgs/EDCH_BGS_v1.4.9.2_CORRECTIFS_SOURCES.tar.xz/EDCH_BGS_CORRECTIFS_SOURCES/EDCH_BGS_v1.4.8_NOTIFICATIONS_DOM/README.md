# EDCH BGS — Correctif NOTIFICATIONS v1.4.8 (DOM)

## Pourquoi ce correctif est différent

Les versions v1.4.5–v1.4.7 changeaient uniquement `public/styles.css`. En présence d'un ancien CSS (ou d'un ancien binaire encore lancé), l'onglet `NOTIFICATIONS` pouvait rester inversé malgré les modifications. Le bouton est construit par `src/ui/notifier.ts`.

Cette version **corrige directement le bouton et ses deux éléments internes au moment de leur création** : le sens de lecture est `ltr`, le texte reste horizontal, et les rotations sont neutralisées par des styles **inline prioritaires**. Le masquage de l'onglet reste opérationnel, car le correctif ne force pas `display`.

Ce correctif ne modifie pas les données BGS, SQLite, les journaux Elite Dangerous, les `.binds`, les commandes X52 Pro ni la Pull Request officielle.

## Installation sur Manjaro

1. Fermer **toutes** les fenêtres EDCH. Vérifier `pgrep -a -x edch` si besoin.
2. Décompresser l'archive dans `~/Téléchargements`.
3. Exécuter :

```bash
cd ~/Téléchargements/EDCH_BGS_v1.4.8_NOTIFICATIONS_DOM
bash -o pipefail -c './installer_manjaro.sh 2>&1 | tee "$HOME/edch-notifications-v148.log"'
```

Le script teste la correction, sauvegarde le fichier original dans `~/EDCH-BGS-Manjaro/.edch-bgs-backup-v1.4.8/`, applique la modification à `src/ui/notifier.ts`, exécute Prettier puis `npm test` et `npm run app:build`.

Le script **n'exécute pas** le nouveau binaire si la compilation échoue.

Pour vérifier uniquement la modification sans compilation (ne change pas l'application active) :

```bash
EDCH_NO_BUILD=1 ./installer_manjaro.sh
```

## Diagnostic du programme réellement présent

```bash
cd ~/Téléchargements/EDCH_BGS_v1.4.8_NOTIFICATIONS_DOM
python3 tools/diagnostic_v148.py ~/EDCH-BGS-Manjaro --build-native
pgrep -a -x edch
```

Le diagnostic vérifie la présence du marqueur v1.4.8 dans le code TypeScript et JS compilé, la synchronisation CSS et **la date du binaire natif par rapport au JS**. Si EDCH est ouvert, il donne aussi le chemin exact du programme chargé par le noyau Linux.

Si le diagnostic est bon et le programme fermé, lancer :

```bash
WEBKIT_DISABLE_DMABUF_RENDERER=1 ~/EDCH-BGS-Manjaro/src-tauri/target/release/edch
```

**Attention :** s'il existe un raccourci sur le bureau qui démarre une autre installation d'EDCH, son exécutable peut être différent. Lancer le chemin exact ci-dessus pour tester.

## Tests

Les tests de `tests/test_v148.py` couvrent : application ciblée du patch, idempotence, refus de sources incompatibles, sauvegarde atomique, TypeScript strict et simulation du bouton DOM / de son libellé et badge. Il faut encore vérifier l'affichage réel sur Manjaro/WebKitGTK.
