#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import subprocess
import sys
import tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from apply_v148 import patch, run, HELPER, MARKER
BASE = '''import { h } from "./dom.js";
let tab: HTMLElement | null = null;
let badge: HTMLElement | null = null;
let panel: HTMLElement | null = null;
/** Mounts the side tab once; `render` builds the panel's content each time it opens or refreshes. */
export function mountSideTab() {
  badge = h("span.side-tab-badge", { hidden: true });
  tab = h(
    "button.side-tab",
    { title: "Notifications" },
    h("span.side-tab-label", null, "NOTIFICATIONS"),
    badge,
  );
  document.body.append(tab, panel);
  refresh();
}
'''
def run_test(name, fn):
    fn();print('OK :',name)
def works():
    out=patch(BASE)
    assert MARKER in out and out.count('forceReadableSideTab();')==1
    assert out.index('document.body.append(tab, panel);')<out.index('forceReadableSideTab();')
    for fragment in ['"horizontal-tb", "important"','"none", "important"','"ltr", "important"','tab.dataset.edchNotificationsFix = "v148"']:
        assert fragment in out,fragment
    assert 'display", "inline-flex' not in out
    assert 'refresh();' in out
    assert patch(out)==out
run_test('application DOM ciblée, horizontal LTR et transformations neutralisées',works)
run_test('deuxième installation idempotente',lambda:None if patch(patch(BASE))==patch(BASE) else (_ for _ in ()).throw(AssertionError()))
def malformed():
    for input in (BASE.replace('button.side-tab','button.other'),BASE.replace('document.body.append(tab, panel);','document.body.append(panel);'),BASE+'\n'+MARKER):
        try:patch(input)
        except ValueError:continue
        raise AssertionError('Source incompatible acceptée')
run_test('refus des sources incompatibles ou partielles',malformed)
def filesystem():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d);(p/'src/ui').mkdir(parents=True)
        f=p/'src/ui/notifier.ts';f.write_text(BASE)
        assert 'simulation' in run(p,True) and f.read_text()==BASE
        assert 'appliqué' in run(p) and f.read_text()==patch(BASE)
        assert 'déjà présent' in run(p)
        backups=list((p/'.edch-bgs-backup-v1.4.8').glob('*.bak'))
        assert len(backups)==1 and backups[0].read_text()==BASE
run_test('sauvegarde atomique et simulation sans modification',filesystem)
def ts_strict():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'check.ts'
        p.write_text('let tab: HTMLElement | null = null;\n'+HELPER+'function demo() { forceReadableSideTab(); }\n')
        proc=subprocess.run(['tsc','--noEmit','--strict','--target','ES2022','--lib','es2022,dom',str(p)],capture_output=True,text=True)
        assert proc.returncode==0,proc.stdout+proc.stderr
run_test('TypeScript strict sur le helper DOM',ts_strict)
def test_runtime():
    with tempfile.TemporaryDirectory() as d:
        base=Path(d)
        src=base/'runtime.ts'
        src.write_text('''
class FakeElement {
  public attrs: Record<string,string> = {};
  public styles: Record<string,[string,string]> = {};
  public dataset: Record<string,string> = {};
  public style = {setProperty:(name: string, value:string, importance:string)=>{ this.styles[name] = [value,importance]; }};
  constructor(public children:Record<string,FakeElement>={}){}
  setAttribute(k:string,v:string){this.attrs[k]=v;}
  querySelector<T>(_selector:string):T|null {return (this.children[_selector] ?? null) as T|null;}
}
const label = new FakeElement();const badge = new FakeElement();
let tab:HTMLElement|null = new FakeElement({'.side-tab-label':label,'.side-tab-badge':badge}) as unknown as HTMLElement;
''' + HELPER + '''
forceReadableSideTab();
const tabInstance=tab as unknown as FakeElement;
for (const element of [tabInstance,label,badge]) {
 if (element.attrs.dir!=='ltr') throw new Error('Direction wrong');
 if (element.styles['writing-mode'][0]!=='horizontal-tb') throw new Error('Vertical!');
 if (element.styles.transform[0]!=='none') throw new Error('Rotated!');
 if (element.styles.transform[1]!=='important') throw new Error('Specificity ignored');
}
if ('display' in tabInstance.styles) throw new Error('Hidden notifications overridden!');
if (tabInstance.dataset.edchNotificationsFix!=='v148') throw new Error('Marker missing');
console.log('OK DOM - parent, label and badge normalized');
''')
        ts=subprocess.run(['tsc','--target','ES2022','--strict','--lib','es2022,dom','--module','commonjs','--outDir',str(base/'out'),str(src)],capture_output=True,text=True)
        assert ts.returncode==0, ts.stdout+ts.stderr
        node=subprocess.run(['node',str(base/'out/runtime.js')],capture_output=True,text=True)
        assert node.returncode==0,node.stdout+node.stderr
run_test('simulation DOM : texte, onglet et badge droits, masquage non forcé',test_runtime)
print('Tous les tests du correctif v1.4.8 sont réussis (6 vérifications).')
