#!/usr/bin/env python3
"""Apply a narrowly-scoped v1.4.8 fix to the real Notifications side tab in src/ui/notifier.ts."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from pathlib import Path
import os
import re
import sys
import tempfile

MARKER = "EDCH-NOTIFICATIONS-V148"
HELPER = '''/** EDCH-NOTIFICATIONS-V148: neutralize legacy CSS rotations in the actual WebKitGTK DOM. */
function forceReadableSideTab() {
  if (!tab) return;
  const orient = (element: HTMLElement) => {
    element.setAttribute("dir", "ltr");
    element.style.setProperty("direction", "ltr", "important");
    element.style.setProperty("writing-mode", "horizontal-tb", "important");
    element.style.setProperty("text-orientation", "mixed", "important");
    element.style.setProperty("transform", "none", "important");
    element.style.setProperty("unicode-bidi", "isolate", "important");
  };
  orient(tab);
  tab.style.setProperty("flex-direction", "row", "important");
  // Never force display: the [hidden] / focus-mode rules must keep working.
  const label = tab.querySelector<HTMLElement>(".side-tab-label");
  if (label) {
    orient(label);
    label.style.setProperty("white-space", "nowrap", "important");
  }
  const counter = tab.querySelector<HTMLElement>(".side-tab-badge");
  if (counter) orient(counter);
  tab.dataset.edchNotificationsFix = "v148";
}

'''
ANCHOR = '/** Mounts the side tab once; `render` builds the panel\'s content each time it opens or refreshes. */'
CALL_ANCHOR = 'document.body.append(tab, panel);'
CALL = 'document.body.append(tab, panel);\n  forceReadableSideTab();'

def patch(source: str) -> str:
    if source.count(MARKER) == 1 and source.count('forceReadableSideTab();') == 1:
        return source
    if MARKER in source or 'forceReadableSideTab' in source:
        raise ValueError('Correctif v1.4.8 partiellement installé : aucun fichier modifié')
    if source.count(ANCHOR) != 1 or source.count(CALL_ANCHOR) != 1:
        raise ValueError('Structure de src/ui/notifier.ts incompatible : aucune modification')
    if not re.search(r'\btab\s*=\s*h\(\s*["\']button\.side-tab', source):
        raise ValueError('Bouton Notifications inattendu : aucune modification')
    if not re.search(r'\bbadge\s*=\s*h\(\s*["\']span\.side-tab-badge', source):
        raise ValueError('Compteur Notifications inattendu : aucune modification')
    return source.replace(ANCHOR, HELPER + ANCHOR, 1).replace(CALL_ANCHOR, CALL, 1)

def run(project: Path, dry: bool = False) -> str:
    file = project / 'src/ui/notifier.ts'
    if not file.is_file() or file.is_symlink():
        raise ValueError(f'Fichier introuvable ou lien symbolique : {file}')
    old = file.read_bytes()
    new = patch(old.decode('utf-8')).encode('utf-8')
    if old == new:
        return 'OK : correctif v1.4.8 déjà présent (sans modification)'
    if dry:
        return 'OK : patch applicable, source inchangée (simulation)'
    backup_dir = project / '.edch-bgs-backup-v1.4.8'
    backup_dir.mkdir(exist_ok=True)
    backup_path = backup_dir / f"notifier.ts.{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')}.bak"
    with backup_path.open('xb') as output:
        output.write(old)
    os.chmod(backup_path, 0o600)
    fd, tmppath = tempfile.mkstemp(dir=file.parent, prefix='.edch-notifier-v148-')
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(new)
        os.chmod(tmppath, file.stat().st_mode & 0o777)
        os.replace(tmppath, file)
    finally:
        if os.path.exists(tmppath): os.unlink(tmppath)
    return f'OK : correctif DOM Notifications appliqué\nSauvegarde : {backup_path}'

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, default=Path.home() / 'EDCH-BGS-Manjaro')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    try:
        print(run(args.project.expanduser().resolve(), args.dry_run))
        return 0
    except (ValueError, OSError, UnicodeError) as e:
        print('ERREUR :', e, file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
