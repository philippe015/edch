#!/usr/bin/env python3
"""Checks the *actual* native build, not merely that a CSS source contains a tag."""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import os
import subprocess
import sys

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('project', nargs='?', default=str(Path.home()/'EDCH-BGS-Manjaro'))
    mode=ap.add_mutually_exclusive_group()
    mode.add_argument('--build-js', action='store_true')
    mode.add_argument('--build-native', action='store_true')
    a=ap.parse_args()
    root=Path(a.project).expanduser().resolve()
    source=root/'src/ui/notifier.ts'
    js=root/'dist/js/ui/notifier.js'
    css=root/'public/styles.css'
    dist_css=root/'dist/styles.css'
    exe=root/'src-tauri/target/release/edch'
    failed=False
    for p in (source,js,css,dist_css,exe):
        print(('PRESENT' if p.is_file() else 'ABSENT '), p)
        if p.is_file(): print('  date:',datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec='seconds'))
    for p,marker in [(source,'EDCH-NOTIFICATIONS-V148'),(js,'edchNotificationsFix')]:
        if not p.is_file() or marker not in p.read_text(errors='replace'):
            print('ERREUR : marqueur absent :',p)
            failed=True
        else: print('OK : marqueur présent :',p)
    if css.is_file() and dist_css.is_file():
        eq=hashlib.sha256(css.read_bytes()).digest()==hashlib.sha256(dist_css.read_bytes()).digest()
        print('CSS source = distribué :', 'OUI' if eq else 'NON')
        if not eq:failed=True
    else: failed=True
    if a.build_native:
        if not exe.is_file() or not js.is_file() or exe.stat().st_mtime_ns < js.stat().st_mtime_ns:
            print('ERREUR : binaire potentiellement plus ancien que le JavaScript du patch')
            failed=True
        else:print('OK : exécutable mis à jour après le JavaScript')
    try:
        pids=subprocess.run(['pgrep','-x','edch'],capture_output=True,text=True).stdout.split()
        for pid in pids:
            process=f'/proc/{pid}/exe'
            print('EDCH actuellement lancé : PID',pid,'fichier',os.path.realpath(process))
    except OSError:pass
    return 1 if failed else 0

if __name__=='__main__':sys.exit(main())
