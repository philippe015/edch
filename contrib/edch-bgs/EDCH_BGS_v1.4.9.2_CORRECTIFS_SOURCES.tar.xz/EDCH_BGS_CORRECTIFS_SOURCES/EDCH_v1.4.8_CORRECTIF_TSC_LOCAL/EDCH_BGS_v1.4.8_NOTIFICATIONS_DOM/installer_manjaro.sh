#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${EDCH_ROOT:-$HOME/EDCH-BGS-Manjaro}"
[[ -d "$ROOT/src" && -f "$ROOT/package.json" ]] || { echo "ERREUR : projet EDCH introuvable : $ROOT" >&2; exit 1; }
export EDCH_ROOT="$ROOT"
if [[ ! -x "$ROOT/node_modules/.bin/tsc" ]]; then
  echo 'ERREUR : TypeScript non installé localement dans le projet EDCH.' >&2
  echo "Exécuter : cd "$ROOT" && npm install --no-package-lock" >&2
  exit 1
fi
export PATH="$ROOT/node_modules/.bin:$PATH"
python3 "$HERE/tests/test_v148.py"
if pgrep -x edch >/dev/null; then
  echo "ERREUR : EDCH est encore en cours d'exécution. Quitter EDCH avant d'installer." >&2
  echo 'Instances détectées :'
  for pid in $(pgrep -x edch); do
    printf '%s : ' "$pid"
    readlink -f "/proc/$pid/exe" || true
  done
  exit 1
fi
python3 "$HERE/apply_v148.py" --project "$ROOT"
if [[ "${EDCH_NO_BUILD:-0}" == "1" ]]; then
  echo 'Sources modifiées uniquement. Aucun changement dans le programme avant recompilation.'
  exit 0
fi
cd "$ROOT"
[[ -x node_modules/.bin/prettier ]] || { echo 'ERREUR : Prettier absent. Faire : npm install --no-package-lock' >&2; exit 1; }
node_modules/.bin/prettier --write src/ui/notifier.ts public/styles.css
npm test
python3 "$HERE/tools/diagnostic_v148.py" "$ROOT" --build-js
OLD=0
[[ ! -f src-tauri/target/release/edch ]] || OLD="$(stat -c %Y src-tauri/target/release/edch)"
npm run app:build
[[ -x src-tauri/target/release/edch ]] || { echo 'ERREUR : binaire EDCH non généré' >&2; exit 1; }
NEW="$(stat -c %Y src-tauri/target/release/edch)"
[[ "$NEW" -ge "$OLD" ]] || { echo 'ERREUR : binaire plus ancien' >&2; exit 1; }
python3 "$HERE/tools/diagnostic_v148.py" "$ROOT" --build-native
echo 'OK : patch DOM et compilation terminés.'
echo 'Lancer : WEBKIT_DISABLE_DMABUF_RENDERER=1 "$HOME/EDCH-BGS-Manjaro/src-tauri/target/release/edch"'
