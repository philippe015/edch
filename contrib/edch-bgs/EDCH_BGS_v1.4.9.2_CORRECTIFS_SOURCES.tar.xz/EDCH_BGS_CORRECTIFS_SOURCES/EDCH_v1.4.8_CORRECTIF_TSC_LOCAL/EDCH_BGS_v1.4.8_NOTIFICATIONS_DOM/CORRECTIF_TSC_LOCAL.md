# Correctif v1.4.8 — Compilateur TypeScript local

Le script de tests cherchait une commande globale `tsc`, absente sur certains Manjaro.

Ce correctif remplace **uniquement** :

- `EDCH_BGS_v1.4.8_NOTIFICATIONS_DOM/tests/test_v148.py` : utilise en priorité le binaire local `~/EDCH-BGS-Manjaro/node_modules/.bin/tsc` ; à défaut, un `tsc` du PATH pour permettre les tests hors projet.
- `EDCH_BGS_v1.4.8_NOTIFICATIONS_DOM/installer_manjaro.sh` : vérifie TypeScript dès le début et expose le dossier `node_modules/.bin` avant les tests.

Aucun fichier du projet EDCH n'est directement changé par l'extraction. La compilation ne démarre que si les tests réussissent. 

## Installer

```bash
cd ~/Téléchargements
unzip -o EDCH_v1.4.8_CORRECTIF_TSC_LOCAL.zip
cd EDCH_BGS_v1.4.8_NOTIFICATIONS_DOM
bash -n installer_manjaro.sh
./installer_manjaro.sh
```

Si le projet n'a pas TypeScript localement, exécuter une seule fois :

```bash
cd ~/EDCH-BGS-Manjaro
npm install --no-package-lock
```

Puis relancer l'installateur. Il n'est pas nécessaire d'installer TypeScript globalement.
