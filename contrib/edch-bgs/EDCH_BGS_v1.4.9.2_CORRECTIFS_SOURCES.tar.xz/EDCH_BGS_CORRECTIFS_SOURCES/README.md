# EDCH BGS Manjaro — Correctifs sources jusqu'à v1.4.9.2

Ce paquet archive les scripts, nouveaux modules, tests et instructions des correctifs créés après la branche v1.4.2 de la PR amont. Il NE remplace PAS un dépôt EDCH complet ni le binaire Tauri compilé. Installer les patchs dans l'ordre en vérifiant les prérequis et en conservant les sauvegardes.

Ordre des correctifs sources :
1. EDCH_BGS_Manjaro_v1.4.3_PDF
2. EDCH_BGS_Manjaro_v1.4.4_BINDINGS_PIED
3. EDCH_BGS_v1.4.8_NOTIFICATIONS_DOM
4. EDCH_v1.4.8_CORRECTIF_TSC_LOCAL (sur l'installateur v1.4.8)
5. EDCH_v1.4.8_CORRECTIF_20_TRADUCTIONS
6. EDCH_BGS_Manjaro_v1.4.9_FIABILITE
7. EDCH_BGS_v1.4.9.1_MISSIONS_ESCADRILLE
8. EDCH_BGS_v1.4.9.2_CHANGEMENT_FACTION

ATTENTION : les patches ne garantissent pas le succès d'une réinstallation sur une autre copie. La source de référence est le projet local fonctionnel sur Manjaro ; utiliser le script de publication de ce dernier pour mettre la totalité de la version dans le fork GitHub.

Aucun journal personnel ou configuration de jeu n'a été ajouté volontairement à cette archive.
